"""
upload_to_s3.py
===============

Run this in Colab (or any machine with the data + AWS credentials).
Uploads the massif_hidden_states data folder + the analysis scripts to S3,
so the SageMaker notebook can pull them down.

Usage:
    # If you have AWS CLI configured (via `aws configure`):
    python upload_to_s3.py --bucket sagemaker-eu-central-1-119287771635

    # If you want to pass creds inline:
    python upload_to_s3.py --bucket sagemaker-eu-central-1-119287771635 \\
        --aws-access-key-id AKIA... --aws-secret-access-key ...

    # Custom source paths:
    python upload_to_s3.py --bucket YOUR_BUCKET \\
        --data-dir /content/drive/MyDrive/massif_hidden_states \\
        --scripts-dir /content/massif_hidden_states_pipeline
"""

import os
import sys
import argparse
import tarfile
import tempfile
from pathlib import Path


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bucket", required=True,
                    help="S3 bucket name (e.g. sagemaker-eu-central-1-119287771635)")
    ap.add_argument("--prefix", default="massif_migration/",
                    help="S3 key prefix (default: massif_migration/)")
    ap.add_argument("--data-dir", default="/content/drive/MyDrive/massif_hidden_states",
                    help="Path to collected traces (default: Colab Drive path)")
    ap.add_argument("--scripts-dir", default=None,
                    help="Path to the .py scripts. If None, uses CWD.")
    ap.add_argument("--aws-access-key-id", default=os.environ.get("AWS_ACCESS_KEY_ID"))
    ap.add_argument("--aws-secret-access-key", default=os.environ.get("AWS_SECRET_ACCESS_KEY"))
    ap.add_argument("--region", default=os.environ.get("AWS_REGION",
                                                        os.environ.get("AWS_DEFAULT_REGION",
                                                                        "eu-central-1")))
    ap.add_argument("--dry-run", action="store_true",
                    help="Print what would be uploaded without actually uploading")
    return ap.parse_args()


def get_s3_client(args):
    try:
        import boto3
    except ImportError:
        print("[err] boto3 not installed. Run: pip install boto3")
        sys.exit(1)
    kwargs = {"region_name": args.region}
    if args.aws_access_key_id and args.aws_secret_access_key:
        kwargs["aws_access_key_id"] = args.aws_access_key_id
        kwargs["aws_secret_access_key"] = args.aws_secret_access_key
    return boto3.client("s3", **kwargs)


def find_scripts_dir(args):
    """Find the directory containing massif_features.py, collect_hidden_states.py, etc."""
    if args.scripts_dir:
        return Path(args.scripts_dir)
    # Search common locations
    candidates = [
        Path.cwd(),
        Path("/content"),
        Path("/content/massif_hidden_states_pipeline"),
        Path("/content/drive/MyDrive/massif_hidden_states_pipeline"),
    ]
    for c in candidates:
        if (c / "massif_features.py").exists():
            return c
    print(f"[err] couldn't find massif_features.py in any of: {candidates}")
    print("      pass --scripts-dir explicitly")
    sys.exit(1)


def make_tarball(scripts_dir: Path, data_dir: Path, out_path: Path):
    """Create a single tarball containing both scripts and data."""
    print(f"[tar] creating {out_path.name} ...")
    with tarfile.open(out_path, "w:gz") as tar:
        # Add scripts
        if scripts_dir.exists():
            print(f"[tar] adding scripts from {scripts_dir}")
            for f in scripts_dir.glob("*.py"):
                tar.add(f, arcname=f"scripts/{f.name}")
            for f in scripts_dir.glob("*.md"):
                tar.add(f, arcname=f"scripts/{f.name}")
            for f in scripts_dir.glob("*.tex"):
                tar.add(f, arcname=f"scripts/{f.name}")

        # Add data
        if data_dir.exists():
            print(f"[tar] adding data from {data_dir}")
            tar.add(data_dir, arcname="data/massif_hidden_states", recursive=True)
        else:
            print(f"[warn] data dir not found: {data_dir}")
            print("       (only scripts will be uploaded)")

    size_mb = out_path.stat().st_size / 1e6
    print(f"[tar] done: {out_path} ({size_mb:.1f} MB)")
    return size_mb


def upload_file(s3, bucket, key, path):
    print(f"[s3] uploading {path.name} -> s3://{bucket}/{key}")
    s3.upload_file(str(path), bucket, key,
                    Callback=lambda bytes_transferred: None)  # silent; could add progress
    print(f"[s3] done")


def main():
    args = parse_args()
    scripts_dir = find_scripts_dir(args)
    data_dir = Path(args.data_dir)

    print(f"[plan] bucket: {args.bucket}")
    print(f"[plan] prefix: {args.prefix}")
    print(f"[plan] scripts: {scripts_dir}")
    print(f"[plan] data:    {data_dir}")
    print()

    # Make tarball
    with tempfile.TemporaryDirectory() as tmpdir:
        tarball = Path(tmpdir) / "massif_migration.tar.gz"
        size_mb = make_tarball(scripts_dir, data_dir, tarball)
        if size_mb > 5000:
            print(f"[warn] tarball is {size_mb:.0f} MB — S3 multipart upload will be used")

        if args.dry_run:
            print("[dry-run] skipping upload")
            return

        s3 = get_s3_client(args)
        key = f"{args.prefix}massif_migration.tar.gz"
        upload_file(s3, args.bucket, key, tarball)

        print()
        print("=" * 70)
        print("UPLOAD COMPLETE")
        print("=" * 70)
        print(f"S3 URI:  s3://{args.bucket}/{key}")
        print()
        print("Next: on SageMaker, run:")
        print(f"  aws s3 cp s3://{args.bucket}/{key} /home/ec2-user/SageMaker/")
        print(f"  cd /home/ec2-user/SageMaker && tar -xzf massif_migration.tar.gz")
        print(f"  cd scripts && pip install scikit-learn pandas matplotlib groq")
        print(f"  python analysis_a_massif.py --data-dir ../data/massif_hidden_states --min-overlap 1 --re-judge --n-permutations 200")


if __name__ == "__main__":
    main()
