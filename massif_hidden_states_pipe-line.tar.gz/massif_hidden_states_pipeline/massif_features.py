"""
massif_features.py
=================

MASSIF feature family for hallucination prediction.

Extends the original MASSIF hierarchy (I_t, sigma_t, Phi_t, Psi_t, kappa_t)
from the Latent_Stability_Observatory with:

  (1) R_t — Kuramoto-style latent synchronization order parameter
      (Zenodo 20542872 / 20575616). Two flavours:
        - R_t_cross_layer:   across layers at each token position
        - R_t_within_traj:   across tokens within a sliding window at each layer

  (2) V_t, A_t — first and second temporal derivatives of R_t
      (Zenodo 20542872). These define the four dynamical classes:
        Accelerator (V_t > 0), Decelerator (V_t < 0),
        Neutral (V_t ≈ 0), Instant (no precursor).

  (3) Eigenvalue spectrum features of the layer-wise covariance matrix
      (INSIDE framework, ICLR 2024 — referenced as iclr2024inside in the
       null-pilot paper). Replaces variance-only (covariance diagonal) with
       full covariance structure: top-k eigenvalues, spectral entropy,
       participation ratio, effective rank.

  (4) tau_collapse horizon — estimated time before persistence flip
      (Zenodo 20542872). Adapted for single-trajectory data: uses the
       within-trajectory R_t slope to project when R_t will cross the
       synchronization threshold.

All features are computed PER PROMPT, producing a feature vector that can be
fed to LASSO + permutation testing.

Input: hidden_states tensor of shape [n_tokens, n_layers, d_model] (bf16 OK)
Output: dict of feature_name -> scalar value (for the prompt)
"""

import numpy as np
import torch
from typing import Dict, List, Optional


# ============================================================
# Helpers
# ============================================================

def _to_float(arr):
    """bf16/fp16 -> float32 for numerical stability."""
    if isinstance(arr, torch.Tensor):
        return arr.float().numpy()
    return np.asarray(arr, dtype=np.float32)


def _safe_unit(h, eps=1e-8):
    """Row-wise L2 normalization. h shape [N, d] -> [N, d]."""
    if isinstance(h, torch.Tensor):
        norm = h.norm(dim=-1, keepdim=True).clamp_min(eps)
        return h / norm
    h = np.asarray(h, dtype=np.float32)
    norm = np.linalg.norm(h, axis=-1, keepdims=True)
    norm = np.maximum(norm, eps)
    return h / norm


def _cosine(a, b, eps=1e-8):
    """Cosine similarity, scalar inputs (1D vectors)."""
    if isinstance(a, torch.Tensor):
        dot = (a * b).sum()
        na = a.norm().clamp_min(eps)
        nb = b.norm().clamp_min(eps)
        return float((dot / (na * nb)).item())
    a = np.asarray(a, dtype=np.float32)
    b = np.asarray(b, dtype=np.float32)
    dot = float(a @ b)
    na = np.linalg.norm(a) + eps
    nb = np.linalg.norm(b) + eps
    return dot / (na * nb)


# ============================================================
# Level 1: persistence I_t (per layer)
# ============================================================

def persistence_per_layer(h):
    """
    I_t at each layer: cosine between consecutive token hidden states.

    Input:  h [n_tokens, n_layers, d_model]
    Output: I [n_tokens-1, n_layers]
    """
    h = _to_float(h)
    # normalize
    norms = np.linalg.norm(h, axis=-1, keepdims=True)
    norms = np.maximum(norms, 1e-8)
    u = h / norms  # unit vectors

    # cosine between consecutive tokens, per layer
    # u[:-1] : [n_tok-1, n_layers, d]
    # u[1:]  : [n_tok-1, n_layers, d]
    dots = np.sum(u[:-1] * u[1:], axis=-1)  # [n_tok-1, n_layers]
    # already unit norm so this IS the cosine
    return dots  # [n_tok-1, n_layers]


# ============================================================
# Level 2-5: sigma_t, Phi_t, Psi_t, kappa_t (per layer)
# ============================================================

def sigma_t_per_layer(I, window_k=4):
    """
    Rolling local tension at each layer.
    I: [n_tok-1, n_layers]
    Output: [n_tok-1, n_layers]  (first window_k entries are NaN)
    """
    n, L = I.shape
    out = np.full_like(I, np.nan)
    for t in range(window_k, n):
        out[t] = np.std(I[t-window_k:t], axis=0)
    return out


def phi_t_per_layer(sigma, I=None):
    """Volatility gradient: diff of sigma along time axis."""
    diff = np.diff(sigma, axis=0)
    pad = np.full((1, sigma.shape[1]), np.nan)
    return np.vstack([pad, diff])  # same length as sigma


def psi_t_per_layer(phi, window_m=3):
    """Smoothed volatility velocity."""
    n, L = phi.shape
    out = np.full_like(phi, np.nan)
    for t in range(window_m, n):
        out[t] = np.mean(phi[t-window_m:t], axis=0)
    return out


def kappa_t_per_layer(h):
    """
    Curvature per layer: arccos(cosine between consecutive *differences*).
    Adapted from observatory (which uses mean over runs; here we have one run).

    Equivalent interpretation: angle between successive velocity vectors
    v_t = h_t - h_{t-1} and v_{t-1} = h_{t-1} - h_{t-2}.

    Input:  h [n_tokens, n_layers, d_model]
    Output: [n_tokens-2, n_layers]  in [0, pi]
    """
    h = _to_float(h)
    # velocities
    v = h[1:] - h[:-1]  # [n_tok-1, n_layers, d]
    # consecutive velocity dot products
    v1 = v[:-1]  # [n_tok-2, n_layers, d]
    v2 = v[1:]   # [n_tok-2, n_layers, d]
    # cosines
    dots = np.sum(v1 * v2, axis=-1)
    n1 = np.linalg.norm(v1, axis=-1) + 1e-8
    n2 = np.linalg.norm(v2, axis=-1) + 1e-8
    cos = np.clip(dots / (n1 * n2), -1.0, 1.0)
    return np.arccos(cos)  # [n_tok-2, n_layers]


# ============================================================
# Level 6: R_t — Kuramoto Latent Synchronization Order Parameter
# ============================================================
# Canonical definition (Metric 8.1):
#
#   R_t^Kuramoto = || (1/N) sum_{r=1}^N u_t^(r) ||_2
#
#   where u_t^(r) = v_t^(r) / ||v_t^(r)||_2
#   and   v_t^(r) = VELOCITY vector at run r, time t  (= h_t^(r) - h_{t-1}^(r))
#
# Two valid ensembles (per the canonical spec):
#   (A) N independent runs of the same prompt (multi-run, requires stochastic sampling)
#   (B) H * L attention heads (single-run, uses per-head outputs as oscillators)
#
# Interpretation:
#   R_t ~ 0.0 : incoherent phase-space dynamics (no shared direction)
#   R_t -> 1.0 : complete phase synchronization (attractor lock-in)
#
# --- IMPORTANT: my previous implementation was WRONG in two ways ---
# (1) Used hidden states h_t directly instead of velocity v_t = h_t - h_{t-1}
# (2) Used surrogate ensembles (across-layers, across-past-tokens) that are
#     NOT in the canonical definition. Those are kept below as
#     "exploratory surrogates" but should not be reported as the canonical R_t.
# --------------------------------------------------------------------

def _velocity(h, eps=1e-8):
    """
    Compute velocity vectors v_t = h_t - h_{t-1}.

    Input:  h [..., n_tokens, ..., d_model]  (last axis = feature dim)
    Output: v of same shape as h but with n_tokens reduced by 1 along
            the time axis. Caller must know which axis is time.
    """
    return h[..., 1:, :] - h[..., :-1, :]


def _unit_normalize(v, eps=1e-8):
    """Row-wise L2 normalization. Works on any shape where last axis is feature."""
    norms = np.linalg.norm(v, axis=-1, keepdims=True)
    norms = np.maximum(norms, eps)
    return v / norms


# ---- (A) CANONICAL: Multi-run ensemble ----

def R_t_kuramoto_multi_run(h_runs):
    """
    Canonical Kuramoto R_t across N independent runs.

    Input:
        h_runs: array of shape [N_runs, n_tokens, n_layers, d_model]
                (each run produces a hidden-state trajectory on the same prompt)

    Output:
        R_t: array of shape [n_tokens - 1, n_layers]
             (n_tokens-1 because velocity is defined between consecutive tokens)
             Each entry R_t[l, t] is in [0, 1].

    NOTE: This is the ONLY function that computes the canonical R_t as defined
    in Metric 8.1. The single-run surrogates below approximate it.
    """
    h_runs = _to_float(h_runs)
    N, n_tok, n_layers, d = h_runs.shape

    # velocity per run: v_t^(r) = h_t^(r) - h_{t-1}^(r)
    # shape: [N, n_tok-1, n_layers, d]
    v = h_runs[:, 1:, :, :] - h_runs[:, :-1, :, :]

    # unit-normalize each velocity vector
    u = _unit_normalize(v)  # [N, n_tok-1, n_layers, d]

    # ensemble average across N runs, then take norm
    # mean over axis 0 (runs)
    mean_u = np.mean(u, axis=0)  # [n_tok-1, n_layers, d]
    R = np.linalg.norm(mean_u, axis=-1)  # [n_tok-1, n_layers]

    # R in [0, 1] by Cauchy-Schwarz (||mean of unit vectors|| <= 1)
    R = np.clip(R, 0.0, 1.0)
    return R


# ---- (B) CANONICAL SURROGATE: H*L attention head ensemble (single-run) ----

def R_t_kuramoto_heads(head_outputs):
    """
    Canonical Kuramoto R_t across H*L attention heads (single-run surrogate).

    Input:
        head_outputs: array of shape [n_tokens, n_layers, n_heads, head_dim]
                      Per-head output BEFORE the W_O projection mixes them.

    Output:
        R_t: array of shape [n_tokens - 1, n_layers]  in [0, 1]

    This is the single-run surrogate explicitly mentioned in the canonical
    definition ("N independent runs or H*L attention heads"). Each (head, layer)
    pair is treated as one oscillator in the ensemble.
    """
    head_outputs = _to_float(head_outputs)
    n_tok, n_layers, n_heads, head_dim = head_outputs.shape

    # velocity: v_t^(h,l) = head_outputs[t, l, h, :] - head_outputs[t-1, l, h, :]
    v = head_outputs[1:] - head_outputs[:-1]  # [n_tok-1, n_layers, n_heads, head_dim]

    # unit-normalize each velocity vector (along head_dim)
    u = _unit_normalize(v)  # [n_tok-1, n_layers, n_heads, head_dim]

    # ensemble average across H*L heads, then take norm.
    # Each (h, l) is one oscillator. Ensemble axis = n_heads.
    # For each (t, l), compute mean over h of u[t, l, h, :], then take norm.
    mean_u = np.mean(u, axis=2)  # [n_tok-1, n_layers, head_dim]
    R = np.linalg.norm(mean_u, axis=-1)  # [n_tok-1, n_layers]

    R = np.clip(R, 0.0, 1.0)
    return R


# ---- (C) EXPLORATORY SURROGATES (kept for comparison, NOT canonical) ----
# These were my original implementations. They use the hidden state directly
# (not velocity) and use non-canonical ensembles (layers / past-tokens).
# Kept so we can compare canonical vs surrogate signal strength.

def R_t_cross_layer_surrogate(h):
    """
    SURROGATE (NOT CANONICAL): ensemble = layers, vector = hidden state (not velocity).

    Input:  h [n_tokens, n_layers, d_model]
    Output: R [n_tokens]   in [0, 1]

    Documents what the old code did. Should NOT be reported as R_t^Kuramoto.
    """
    h = _to_float(h)
    norms = np.linalg.norm(h, axis=-1, keepdims=True)
    norms = np.maximum(norms, 1e-8)
    u = h / norms
    mean_u = np.mean(u, axis=1)
    R = np.linalg.norm(mean_u, axis=-1)
    return np.clip(R, 0.0, 1.0)


def R_t_within_trajectory_surrogate(h, window_k=4):
    """
    SURROGATE (NOT CANONICAL): ensemble = past k tokens, vector = hidden state.

    Input:  h [n_tokens, n_layers, d_model]
    Output: R [n_tokens, n_layers]   in [0, 1]
    """
    h = _to_float(h)
    n_tok, n_layers, d = h.shape
    norms = np.linalg.norm(h, axis=-1, keepdims=True)
    norms = np.maximum(norms, 1e-8)
    u = h / norms
    R = np.full((n_tok, n_layers), np.nan)
    for t in range(window_k, n_tok):
        window = u[t-window_k:t]
        mean_u = np.mean(window, axis=0)
        R[t] = np.linalg.norm(mean_u, axis=-1)
    return np.clip(R, 0.0, 1.0)


# ---- Velocity-corrected single-run surrogates (BETTER than the originals) ----
# These fix the velocity issue but still use a non-canonical ensemble.
# They sit between the old surrogates and the canonical multi-run version.

def R_t_cross_layer_velocity(h):
    """
    VELOCITY-CORRECTED SURROGATE: ensemble = layers, vector = unit velocity.

    Input:  h [n_tokens, n_layers, d_model]
    Output: R [n_tokens - 1, n_layers]  in [0, 1]
            Wait — that's wrong. Cross-layer means ensemble=layers, so R is per-token.
            Actually returns R [n_tokens-1]  (one scalar per token position, after velocity)
    """
    h = _to_float(h)
    n_tok, n_layers, d = h.shape
    # velocity per (token, layer)
    v = h[1:] - h[:-1]  # [n_tok-1, n_layers, d]
    u = _unit_normalize(v)  # [n_tok-1, n_layers, d]
    # ensemble = layers, so average across layers
    mean_u = np.mean(u, axis=1)  # [n_tok-1, d]
    R = np.linalg.norm(mean_u, axis=-1)  # [n_tok-1]
    return np.clip(R, 0.0, 1.0)


def R_t_within_trajectory_velocity(h, window_k=4):
    """
    VELOCITY-CORRECTED SURROGATE: ensemble = past k tokens, vector = unit velocity.

    Input:  h [n_tokens, n_layers, d_model]
    Output: R [n_tokens - 1, n_layers]  in [0, 1]
            (R[t, l] = ||mean of unit velocity over window_k past tokens at layer l||)
    """
    h = _to_float(h)
    n_tok, n_layers, d = h.shape
    # velocity
    v = h[1:] - h[:-1]  # [n_tok-1, n_layers, d]
    u = _unit_normalize(v)  # [n_tok-1, n_layers, d]
    # rolling window over past window_k velocity vectors
    n_v = u.shape[0]
    R = np.full((n_v, n_layers), np.nan)
    for t in range(window_k, n_v):
        window = u[t-window_k:t]  # [k, n_layers, d]
        mean_u = np.mean(window, axis=0)  # [n_layers, d]
        R[t] = np.linalg.norm(mean_u, axis=-1)  # [n_layers]
    return np.clip(R, 0.0, 1.0)


# ============================================================
# Backward-compat shims (so analysis scripts keep working)
# ============================================================
# Old code called R_t_cross_layer() and R_t_within_trajectory().
# We keep those names but redirect to the velocity-corrected surrogates,
# since the velocity-corrected versions are strictly more faithful to the
# canonical definition. The original (non-velocity) surrogates are still
# available as R_t_cross_layer_surrogate / R_t_within_trajectory_surrogate
# for ablation.

def R_t_cross_layer(h):
    """Redirects to velocity-corrected surrogate. See R_t_cross_layer_velocity."""
    return R_t_cross_layer_velocity(h)


def R_t_within_trajectory(h, window_k=4):
    """Redirects to velocity-corrected surrogate. See R_t_within_trajectory_velocity."""
    return R_t_within_trajectory_velocity(h, window_k=window_k)


# ============================================================
# Level 7: V_t, A_t — derivatives of R_t
# ============================================================

def velocity_acceleration(R, eps=1e-8):
    """
    V_t = dR/dt,  A_t = d^2 R / dt^2.

    For 1D R: returns V, A (both length len(R)-1, len(R)-2).
    For 2D R [n_tok, n_layers]: returns V, A both of same shape with NaNs
        in the first/last positions to keep alignment.
    """
    if R.ndim == 1:
        V = np.diff(R)
        A = np.diff(V)
        return V, A
    else:
        V = np.diff(R, axis=0)
        pad_v = np.full((1, R.shape[1]), np.nan)
        V = np.vstack([pad_v, V])
        A = np.diff(V, axis=0)
        pad_a = np.full((1, R.shape[1]), np.nan)
        A = np.vstack([pad_a, A])
        A = np.vstack([pad_a, A])  # match length
        return V, A


# ============================================================
# Level 8: Eigenvalue spectrum features (INSIDE framework)
# ============================================================
# Reference: ICLR 2024 INSIDE paper — uses eigenvalues of intermediate
# layer covariance matrices (EigenScore) to detect hallucination.
# This is the natural covariance-structure extension of variance-only Friction Delta.

def covariance_eigenvalue_features(h, top_k=10):
    """
    For each layer l, compute the covariance matrix across generated tokens:
        C^(l) = (1/n_tok) sum_t (h_t - h_mean)(h_t - h_mean)^T  in R^{d x d}

    Then extract:
      - lambda_1 (largest eigenvalue)
      - lambda_topk (top-k)
      - spectral_entropy = -sum (lambda_i / Z) log(lambda_i / Z)
      - participation_ratio = (sum lambda_i)^2 / sum(lambda_i^2)  (effective # of modes)
      - effective_rank = exp(spectral_entropy)

    Returns dict with keys per feature, values per-layer arrays.

    To keep memory bounded: compute eigenvalues via torch.svd on GPU if
    available, else numpy on CPU. d_model up to ~2300, n_tok up to ~80, so
    C is d x d ~ 2300^2 floats = 21 MB per layer. Fine.
    """
    h = _to_float(h)  # [n_tok, n_layers, d]
    n_tok, n_layers, d = h.shape

    features = {
        "eig_lambda1": np.zeros(n_layers),
        "eig_lambda2": np.zeros(n_layers),
        "eig_lambda1_minus_lambda2": np.zeros(n_layers),
        "eig_spectral_entropy": np.zeros(n_layers),
        "eig_participation_ratio": np.zeros(n_layers),
        "eig_effective_rank": np.zeros(n_layers),
        "eig_trace": np.zeros(n_layers),
    }
    # also store the top-k eigenvalues as a flat feature vector
    topk_per_layer = np.zeros((n_layers, top_k))

    for l in range(n_layers):
        h_l = h[:, l, :]  # [n_tok, d]
        # center
        h_l = h_l - h_l.mean(axis=0, keepdims=True)
        # covariance: d x d. With n_tok ~ 80 and d ~ 2300, rank(C) <= n_tok.
        # Eigenvalues are non-negative; only the first n_tok-1 can be nonzero.
        # Compute via SVD of the centered data matrix instead — much faster.
        # C = (1/n) H^T H where H is [n_tok, d] centered
        # eigenvalues of C = (1/n) * singular_values(H)^2
        try:
            if torch.cuda.is_available():
                h_t = torch.from_numpy(h_l).cuda()
                # SVD: H = U S V^T
                s = torch.linalg.svdvals(h_t).cpu().numpy()
            else:
                s = np.linalg.svd(h_l, compute_uv=False)
            eigvals = (s ** 2) / max(n_tok - 1, 1)  # [d] but only first n_tok-1 nonzero
            eigvals = np.maximum(eigvals, 0)
        except Exception:
            eigvals = np.zeros(min(d, n_tok))

        # take top_k
        k = min(top_k, len(eigvals))
        topk = np.sort(eigvals)[::-1][:k]
        if len(topk) < top_k:
            topk = np.pad(topk, (0, top_k - len(topk)))

        features["eig_lambda1"][l] = topk[0] if k >= 1 else 0.0
        features["eig_lambda2"][l] = topk[1] if k >= 2 else 0.0
        features["eig_lambda1_minus_lambda2"][l] = (topk[0] - topk[1]) if k >= 2 else topk[0]
        features["eig_trace"][l] = np.sum(eigvals)

        # spectral entropy over normalized eigenvalue distribution
        total = np.sum(eigvals)
        if total > 1e-12:
            p = eigvals / total
            p = p[p > 1e-12]
            H = -np.sum(p * np.log(p))
        else:
            H = 0.0
        features["eig_spectral_entropy"][l] = H
        features["eig_effective_rank"][l] = float(np.exp(H)) if H > 0 else 0.0

        # participation ratio: (sum lambda)^2 / sum(lambda^2)
        sq_sum = np.sum(eigvals ** 2)
        if sq_sum > 1e-12:
            features["eig_participation_ratio"][l] = (total ** 2) / sq_sum
        else:
            features["eig_participation_ratio"][l] = 0.0

        topk_per_layer[l] = topk

    features["eig_topk"] = topk_per_layer  # [n_layers, top_k]
    return features


# ============================================================
# Level 9: tau_collapse horizon
# ============================================================
# (Zenodo 20542872) — estimated time before persistence flip
#
# Adapted: project when within-trajectory R_t crosses a threshold
# (synchronization -> attractor lock-in). If R_t is rising and projected
# to cross 0.8 within the next n_tokens steps, tau_collapse is finite.
# Otherwise infinite.

def tau_collapse_horizon(R_within, threshold=0.8, max_horizon=20):
    """
    R_within: [n_tokens, n_layers] (output of R_t_within_trajectory)

    Returns:
        per-layer array of tau_collapse (int): number of steps until R
        crosses threshold, projected from the slope at the last valid step.
        -1 = already crossed (collapsed at start)
        max_horizon = no collapse predicted within horizon
    """
    if R_within.ndim == 1:
        R_within = R_within[:, None]
    n_tok, n_layers = R_within.shape
    tau = np.full(n_layers, max_horizon)

    for l in range(n_layers):
        col = R_within[:, l]
        valid = ~np.isnan(col)
        if not np.any(valid):
            continue
        idx = np.where(valid)[0]
        last = idx[-1]
        R_last = col[last]
        if R_last >= threshold:
            tau[l] = -1
            continue
        # slope over last 5 valid points
        window = min(5, len(idx))
        recent = col[idx[-window:]]
        if len(recent) >= 2:
            slope = (recent[-1] - recent[0]) / (window - 1)
        else:
            slope = 0.0
        if slope <= 1e-6:
            tau[l] = max_horizon
        else:
            steps_to_thresh = (threshold - R_last) / slope
            tau[l] = int(min(max_horizon, max(-1, int(np.ceil(steps_to_thresh)))))
    return tau


# ============================================================
# CANONICAL GLOSSARY METRICS (v5.0 Audited Synthesis)
# ============================================================
# All metrics below follow the MyceliaLM & MASSIF Master Telemetry Glossary v5.0
# (Solis, October 2026) exactly. Each function is labeled with its Metric ID
# from the glossary.
#
# These are kept SEPARATE from the earlier surrogate implementations above
# so that:
#   (a) canonical metrics are clearly labeled
#   (b) we can directly compare canonical vs surrogate signal strength
#   (c) the audit trail is preserved
# ============================================================


# ---- Section 2: SDE & Fokker-Planck Diagnostics ----

def sde_drift_D1(h_or_runs, axis="layer"):
    """
    Metric 2.1: First-Order Drift Velocity D^(1) / μ_drift.

    Canonical definition:
        D^(1)(z) = lim_{Δt→0} (1/Δt) E[Δz | z_t = z]

    Under the Ito SDE:  dz_t = D^(1) dt + sqrt(2 D^(2)) dW_t

    For our finite-sample, discrete-step data, Δt = 1 and we estimate:
        D^(1) ≈ E[Δz]   (mean increment)

    Args:
        h_or_runs:
            - If 3D [n_tok, n_layers, d]: use as a single trajectory.
              axis="layer" → Δz = h[:, 1:, :] - h[:, :-1, :]  (increments across layers)
              axis="token" → Δz = h[1:, :, :] - h[:-1, :, :]  (increments across tokens)
            - If 4D [N_runs, n_tok, n_layers, d]: use as multi-run ensemble.
              Δz computed along token axis, averaged across runs.
              (This is the canonical ensemble for SDE estimation per Metric 2.1.)

    Returns:
        D1: vector of length d (the mean drift direction)
        ||D1||: scalar (drift magnitude)
    """
    h = _to_float(h_or_runs)
    if h.ndim == 4:
        # multi-run: token-direction increments, averaged across runs
        # h: [N, n_tok, n_layers, d]
        dz = h[:, 1:, :, :] - h[:, :-1, :, :]  # [N, n_tok-1, n_layers, d]
        dz_flat = dz.reshape(-1, dz.shape[-1])
        D1 = np.mean(dz_flat, axis=0)
    elif h.ndim == 3:
        if axis == "layer":
            dz = h[:, 1:, :] - h[:, :-1, :]  # [n_tok, n_layers-1, d]
        else:  # token
            dz = h[1:, :, :] - h[:-1, :, :]  # [n_tok-1, n_layers, d]
        dz_flat = dz.reshape(-1, h.shape[-1])
        D1 = np.mean(dz_flat, axis=0)
    else:
        raise ValueError(f"Expected 3D or 4D input, got {h.ndim}D")
    return D1, float(np.linalg.norm(D1))


def sde_diffusion_D2(h_or_runs, axis="layer"):
    """
    Metric 2.2: Second-Order Diffusion Coefficients D^(2)_tr and D^(2)_dir.

    Canonical definition:
        D^(2)_tr(z) = lim_{Δt→0} (1/(2Δt)) E[(Δz)(Δz)^T | z_t = z]
        D^(2)_dir   = Var_dir(Δz)  (variance along trajectory tangent)

    For our data (Δt = 1):
        D^(2)_tr = (1/2) E[Δz Δz^T]  →  trace = (1/2) E[||Δz||^2]
        D^(2)_dir = variance of Δz projected onto the trajectory tangent

    Glossary healthy ranges:
        D^(2)_dir ∈ [2.2e-4, 2.9e-4]
        D^(2)_tr ≈ 0.0367 (much larger because it sums all dims)
    """
    h = _to_float(h_or_runs)
    if h.ndim == 4:
        dz = h[:, 1:, :, :] - h[:, :-1, :, :]
        dz_flat = dz.reshape(-1, h.shape[-1])
    elif h.ndim == 3:
        if axis == "layer":
            dz = h[:, 1:, :] - h[:, :-1, :]
        else:
            dz = h[1:, :, :] - h[:-1, :, :]
        dz_flat = dz.reshape(-1, h.shape[-1])
    else:
        raise ValueError(f"Expected 3D or 4D input, got {h.ndim}D")

    # trace of D^(2): (1/2) E[||Δz||^2]
    sq_norms = np.sum(dz_flat ** 2, axis=-1)
    D2_tr = 0.5 * float(np.mean(sq_norms))

    # directional variance: variance of the projection of Δz onto its mean direction
    mean_dz = np.mean(dz_flat, axis=0)
    mean_norm = np.linalg.norm(mean_dz) + 1e-12
    # project each increment onto mean direction
    proj = (dz_flat @ mean_dz) / mean_norm  # scalar per increment
    D2_dir = float(np.var(proj))

    return D2_tr, D2_dir


def sde_D4(h_or_runs, axis="layer"):
    """
    Metric 2.3: Fourth-Order Kramers-Moyal Coefficient D^(4).

    Canonical definition:
        D^(4)(z) = lim_{Δt→0} (1/(24 Δt)) E[(Δz)^4 | z_t = z]

    Glossary healthy range: 1e-7 to 1e-6. Sustained > 5e-6 signals non-Langevin jump noise.

    For high-dim Δz, we compute D^(4) on the magnitude ||Δz||:
        D^(4) ≈ (1/24) E[||Δz||^4]
    """
    h = _to_float(h_or_runs)
    if h.ndim == 4:
        dz = h[:, 1:, :, :] - h[:, :-1, :, :]
        dz_flat = dz.reshape(-1, h.shape[-1])
    elif h.ndim == 3:
        if axis == "layer":
            dz = h[:, 1:, :] - h[:, :-1, :]
        else:
            dz = h[1:, :, :] - h[:-1, :, :]
        dz_flat = dz.reshape(-1, h.shape[-1])
    else:
        raise ValueError(f"Expected 3D or 4D input, got {h.ndim}D")

    # ||Δz||^4 averaged
    sq_norms = np.sum(dz_flat ** 2, axis=-1)
    fourth_moment = float(np.mean(sq_norms ** 2))
    D4 = fourth_moment / 24.0
    return D4


def pawula_ratio(D4, D2_dir):
    """
    Metric 2.4: Pawula Diagnostic Ratio.

    R_Pawula = D^(4) / (D^(2)_dir)^2

    Glossary healthy range: 6.0 to 50.0.
    Values > 50.0 signal breakdown of continuous SDE assumptions (heavy tails).
    """
    if D2_dir < 1e-12:
        return 0.0
    return D4 / (D2_dir ** 2)


def sde_snr(D1_norm, D2_tr):
    """
    Metric 2.5: SDE Directional Signal-to-Noise Ratio ρ.

    ρ = ||D^(1)|| / sqrt(D^(2)_tr)

    Regime thresholds (code-verified per glossary):
        ρ > 1.5  → BALLISTIC (deterministic geodesic flow)
        ρ << 1.5 → STOCHASTIC (random walk)
    """
    if D2_tr < 1e-12:
        return float("inf")
    return D1_norm / np.sqrt(D2_tr)


# ---- Section 3: Latent Trajectory Kinematics (canonical) ----

def v_layer_direction(h):
    """
    Metric 3.1: Latent Velocity (LAYER direction).

    v^(l)_t = h^(l)_t - h^(l-1)_t   (layer-to-layer displacement at fixed token t)

    Input:  h [n_tokens, n_layers, d_model]
    Output: v [n_tokens, n_layers-1, d_model]
            (first layer has no predecessor; output has L-1 entries)
    """
    h = _to_float(h)
    return h[:, 1:, :] - h[:, :-1, :]


def a_layer_direction(v_layer):
    """
    Metric 3.2: Latent Acceleration (LAYER direction).

    a^(l)_t = v^(l)_t - v^(l-1)_t

    Input:  v_layer [n_tokens, n_layers-1, d_model] (output of v_layer_direction)
    Output: a [n_tokens, n_layers-2, d_model]
    """
    return v_layer[:, 1:, :] - v_layer[:, :-1, :]


def curvature_canonical(v, a):
    """
    Metric 3.3: Trajectory Curvature (canonical v × a form).

    κ_t = ||v × a|| / ||v||^3

    In high dimensions, the cross-product norm is generalized as:
        ||v × a|| = sqrt(||v||^2 ||a||^2 - (v · a)^2)

    This is the magnitude of the component of a perpendicular to v.

    Input:
        v: [..., d]  velocity vectors at consecutive positions
        a: [..., d]  acceleration vectors at the SAME positions as v
    Output: κ [...]  curvature scalars

    Note: if v has length L and a has length L-1 (because a = diff(v)),
    we must align them — a is the acceleration at v's index 1..L-1, so we
    drop the first v to align with a. Then curvature is computed at L-1 points.
    """
    v = _to_float(v)
    a = _to_float(a)
    if v.ndim != a.ndim:
        raise ValueError(f"v and a must have same ndim, got {v.ndim}D and {a.ndim}D")
    # Find the axis with different lengths and align along it.
    # In canonical layer-direction usage: v is [n_tok, L-1, d], a is [n_tok, L-2, d]
    # The diff axis is axis=1 (layer axis). We slice v[:, 1:, :] so its layer count matches a's.
    diff_axes = [i for i in range(v.ndim) if v.shape[i] != a.shape[i]]
    if not diff_axes:
        # already aligned
        v_aligned, a_aligned = v, a
    else:
        # take the first differing axis (typically the layer axis)
        axis = diff_axes[0]
        min_len = min(v.shape[axis], a.shape[axis])
        # build slices
        v_slices = [slice(None)] * v.ndim
        a_slices = [slice(None)] * a.ndim
        # for velocity, drop the FIRST entry along the diff axis (since a[i] = v[i+1] - v[i])
        if v.shape[axis] > a.shape[axis]:
            v_slices[axis] = slice(1, 1 + min_len)
            a_slices[axis] = slice(0, min_len)
        elif a.shape[axis] > v.shape[axis]:
            a_slices[axis] = slice(1, 1 + min_len)
            v_slices[axis] = slice(0, min_len)
        else:
            v_slices[axis] = slice(0, min_len)
            a_slices[axis] = slice(0, min_len)
        v_aligned = v[tuple(v_slices)]
        a_aligned = a[tuple(a_slices)]
    v_norm_sq = np.sum(v_aligned ** 2, axis=-1)
    a_norm_sq = np.sum(a_aligned ** 2, axis=-1)
    v_dot_a = np.sum(v_aligned * a_aligned, axis=-1)
    cross_sq = np.maximum(v_norm_sq * a_norm_sq - v_dot_a ** 2, 0.0)
    cross_norm = np.sqrt(cross_sq)
    v_norm_cubed = (np.sqrt(v_norm_sq) + 1e-12) ** 3
    return cross_norm / v_norm_cubed


def jerk_canonical(kappa):
    """
    Metric 3.4: Trajectory Jerk.

    j^(l) = |κ^(l) - κ^(l-1)|

    Input:  kappa [...]  (curvature at each layer)
    Output: j [...]      (one fewer entry along last axis)
    """
    kappa = _to_float(kappa)
    return np.abs(np.diff(kappa, axis=-1))


def persistence_layer_direction(v_layer):
    """
    Metric 3.5 (canonical layer-direction reading): Directional Persistence I_t.

    I_t at layer l = cosine between v^(l)_t and v^(l)_{t-1}
    (i.e. how stable is the layer's contribution direction across consecutive tokens)

    Input:  v_layer [n_tokens, n_layers-1, d_model]  (output of v_layer_direction)
    Output: I [n_tokens-1, n_layers-1]  in [-1, 1]

    Regimes (glossary):
        I_t ≈ -1.0  → Anti-persistent (corrective, healthy exploratory)
        I_t ≈ 0.0   → Orthogonal directional reset
        I_t > 0.0   → Persistence flip (attractor lock-in)
    """
    v_layer = _to_float(v_layer)
    v_t = v_layer[1:]      # [n_tok-1, n_layers-1, d]
    v_tm1 = v_layer[:-1]   # [n_tok-1, n_layers-1, d]
    dots = np.sum(v_t * v_tm1, axis=-1)
    n1 = np.linalg.norm(v_t, axis=-1)
    n2 = np.linalg.norm(v_tm1, axis=-1)
    denom = n1 * n2 + 1e-8
    return dots / denom  # [n_tok-1, n_layers-1]


def sigma_t_canonical_multirun(persistence_runs, window_k=4):
    """
    Metric 3.6: Local Tension σ_t (CANONICAL — multi-run ensemble).

    σ_t = std across N runs of rolling persistence Ī_t^(k)

    Glossary healthy range: 0.05 to 0.22.
    Spikes σ_t > 0.35 achieve AUROC > 0.9 in predicting collapse 2-3 tokens in advance.

    Input:
        persistence_runs: list of N arrays, each of shape [n_tok-1, n_layers-1]
                          (per-run I_t from persistence_layer_direction)
    Output:
        sigma_t: [n_tok-1, n_layers-1]  (cross-run std of rolling persistence)
    """
    if len(persistence_runs) < 2:
        # single run — return NaNs (canonical ensemble not available)
        shape = persistence_runs[0].shape if persistence_runs else (0, 0)
        return np.full(shape, np.nan)
    # rolling persistence per run
    rolling = []
    for I in persistence_runs:
        roll = np.full_like(I, np.nan)
        for t in range(window_k, len(I)):
            roll[t] = np.mean(I[t - window_k:t], axis=0)
        rolling.append(roll)
    rolling = np.array(rolling)  # [N, n_tok-1, n_layers-1]
    # cross-run std
    return np.std(rolling, axis=0, ddof=1)


def cross_token_coherence(v):
    """
    Metric 3.9: Cross-Token Directional Coherence c_l.

    c_l = (1/(T(T-1))) Σ_{i≠j} cos(v_i, v_j)

    Glossary interpretation:
        c_l ≈ 0.000  → Individual Ballistic Flow (tokens move independently)
        c_l > 0.800  → Collective Ballistic Alignment (sequence moves as wave)

    Input:  v [n_tokens, n_layers, d_model]  (velocity vectors per token, per layer)
    Output: c [n_layers]  (per-layer mean pairwise cosine)
    """
    v = _to_float(v)
    n_tok, n_layers, d = v.shape
    # unit-normalize
    norms = np.linalg.norm(v, axis=-1, keepdims=True) + 1e-8
    u = v / norms
    c = np.zeros(n_layers)
    for l in range(n_layers):
        u_l = u[:, l, :]  # [n_tok, d]
        sim = u_l @ u_l.T  # [n_tok, n_tok]
        n = sim.shape[0]
        if n > 1:
            c[l] = (sim.sum() - np.trace(sim)) / (n * (n - 1))
        else:
            c[l] = 0.0
    return c


def dubito_score(sigma_head_sq, kappa, C, gamma=1.0):
    """
    Metric 3.10: Dubito Score / Paradox Index.

    Dubito_t = σ^2_head * exp(γ * κ_t) * (1 - C_t)

    Glossary healthy range: 1.2 to 4.5. Paradox threshold: > 7.0.

    Inputs:
        sigma_head_sq: inter-head fiber curvature (Metric 5.2)
        kappa: trajectory curvature (Metric 3.3)
        C: coherence (Metric 5.1)
        gamma: tunable weighting (default 1.0)
    """
    return sigma_head_sq * np.exp(gamma * kappa) * (1.0 - C)


def cfkr_trigger(delta, I_t, eps_flatline=0.05, I_threshold=0.35):
    """
    Metric 4.3: Cache-Fused Kinematic Rail (CFKR) Trigger.

    CFKR_Trigger = 1[|Δ| < ε_flatline AND I_t > 0.35]

    Returns 1 if trigger condition is met, 0 otherwise.
    """
    return int(abs(delta) < eps_flatline and I_t > I_threshold)


# ---- Section 5: Attention Consensus, Head Differentiation ----

def coherence_C(head_outputs):
    """
    Metric 5.1: Coherence C / Acclamation Rate.

    C = (1/T) Σ_t 1[σ^2_attn,t < θ_t]
    θ_t = Median(σ^2_attn) + 1.4826 · MAD(σ^2_attn)

    Glossary healthy range: 0.75 to 0.98 (during training).
    Drops to ≈ 0.00 during specialized fiber untangling.

    Input:
        head_outputs: [n_tokens, n_layers, n_heads, head_dim]
                      (per-attention-head outputs from o_proj pre-hook)

    Returns:
        C: scalar coherence rate (fraction of (token, layer) positions below threshold)
        theta: the adaptive threshold
        head_var: [n_tokens, n_layers] per-position head variance
    """
    head_outputs = _to_float(head_outputs)
    # variance across heads (axis=2), per (token, layer)
    head_var = np.var(head_outputs, axis=2)  # [n_tok, n_layers]
    # adaptive threshold via MAD
    med = float(np.median(head_var))
    mad = float(np.median(np.abs(head_var - med)))
    theta = med + 1.4826 * mad
    # coherence rate
    C = float(np.mean(head_var < theta))
    return C, theta, head_var


def fiber_curvature_sigma_head_sq(head_outputs):
    """
    Metric 5.2: Inter-Head Fiber Curvature σ^2_head.

    σ^2_head = Var_h(κ_t^(h))  (variance of curvature across H heads)

    Glossary healthy range: 0.60 to 0.77.
    Collapse < 0.50 indicates head uniformity (loss of specialization).

    Input:
        head_outputs: [n_tokens, n_layers, n_heads, head_dim]

    Returns:
        sigma_head_sq: [n_tok-2, n_layers]  per-(token, layer) variance of per-head curvature
        kappa_per_head: [n_tok-2, n_layers, n_heads]  per-head curvature
    """
    head_outputs = _to_float(head_outputs)
    n_tok, n_layers, n_heads, head_dim = head_outputs.shape
    # per-head velocity (token direction)
    v = head_outputs[1:] - head_outputs[:-1]  # [n_tok-1, n_layers, n_heads, head_dim]
    # consecutive velocity pairs
    v1 = v[:-1]  # [n_tok-2, n_layers, n_heads, head_dim]
    v2 = v[1:]
    dots = np.sum(v1 * v2, axis=-1)
    n1 = np.linalg.norm(v1, axis=-1) + 1e-8
    n2 = np.linalg.norm(v2, axis=-1) + 1e-8
    cos = np.clip(dots / (n1 * n2), -1.0, 1.0)
    kappa_per_head = np.arccos(cos)  # [n_tok-2, n_layers, n_heads]
    # variance across heads
    sigma_head_sq = np.var(kappa_per_head, axis=-1)  # [n_tok-2, n_layers]
    return sigma_head_sq, kappa_per_head


def decoupling_velocity(sigma_head_sq):
    """
    Metric 5.3: Decoupling Velocity.

    dσ^2_head/dt  ≈  (σ^2_head,t - σ^2_head,t-Δt) / Δt

    Glossary: positive values (> +0.005) confirm active Hidden Descent.
    """
    sigma_head_sq = _to_float(sigma_head_sq)
    return np.diff(sigma_head_sq, axis=0)


def attention_entropy_variance(head_outputs):
    """
    Metric 5.4: Attention Entropy Variance.

    Var(H_attn) = Var({-Σ_j a_ij ln a_ij} across layers and heads)

    For per-head outputs, we compute entropy of the softmax-normalized head outputs
    as a proxy (since we don't have raw attention weights).

    Input:  head_outputs: [n_tokens, n_layers, n_heads, head_dim]
    Returns: scalar variance of entropies
    """
    head_outputs = _to_float(head_outputs)
    # softmax-normalize per (token, layer, head) across head_dim
    # subtract max for numerical stability
    x = head_outputs - np.max(head_outputs, axis=-1, keepdims=True)
    ex = np.exp(x)
    p = ex / (np.sum(ex, axis=-1, keepdims=True) + 1e-12)
    # entropy: -Σ p ln p
    entropy = -np.sum(p * np.log(p + 1e-12), axis=-1)  # [n_tok, n_layers, n_heads]
    return float(np.var(entropy))


def spectral_concentration(h, top_k=16):
    """
    Metric 5.5: Spectral Concentration.

    S_concentration = (Σ_{i=1}^k σ_i) / (Σ_j σ_j)

    (Top-k singular values of hidden-state matrix / total singular values)

    Glossary healthy range: 0.06 to 0.08. > 0.15 indicates dimensional collapse.

    Input:  h [n_tokens, n_layers, d_model]
    Output: S [n_layers]  per-layer spectral concentration
    """
    h = _to_float(h)
    n_tok, n_layers, d = h.shape
    S = np.zeros(n_layers)
    for l in range(n_layers):
        h_l = h[:, l, :]  # [n_tok, d]
        try:
            s = np.linalg.svd(h_l, compute_uv=False)
            k = min(top_k, len(s))
            total = s.sum() + 1e-12
            S[l] = s[:k].sum() / total
        except np.linalg.LinAlgError:
            S[l] = 0.0
    return S


# ---- Section 10: MASSIF Training-Time Stability Observatory ----

def basin_radius(h, max_tokens=64):
    """
    Metric 10.1: Attractor Basin Radius.

    Basin_Radius = Tr(Cov(h^(L)))  (trace of covariance at deepest layer)

    Glossary note: "The code takes the unbiased variance across the first 64
    token positions at the deepest hooked layer and sums over features and batch
    entries. With BATCH_SIZE=1 this is the trace of the within-sequence token
    covariance."

    Glossary healthy range: 67.0 to 91.0 (stable or slowly decreasing).
    Rapid shrinkage indicates imminent attractor basin collapse.

    Input:  h [n_tokens, n_layers, d_model]
    Output: scalar (Basin_Radius at the last layer)
    """
    h = _to_float(h)
    n_tok = min(max_tokens, len(h))
    h_L = h[:n_tok, -1, :]  # [n_tok, d]
    # unbiased variance per feature, summed
    return float(np.sum(np.var(h_L, axis=0, ddof=1)))


def norm_growth_rate(h, max_tokens=64):
    """
    Metric 10.2: Depth-wise Norm-Growth Rate λ_N.

    λ_N = (1/(L-1)) Σ_l ln(‖h^(l+1)‖ / ‖h^(l)‖)

    Glossary: mean over first 64 token positions per layer, then log-ratio.
    Negative values confirm state norm shrinkage (convergence).

    Input:  h [n_tokens, n_layers, d_model]
    Output: scalar (λ_N)
    """
    h = _to_float(h)
    n_tok = min(max_tokens, len(h))
    # mean hidden state across first 64 tokens, per layer
    h_mean = h[:n_tok].mean(axis=0)  # [n_layers, d]
    norms = np.linalg.norm(h_mean, axis=-1)  # [n_layers]
    log_ratios = np.log(norms[1:] / (norms[:-1] + 1e-12) + 1e-12)
    return float(np.mean(log_ratios))


def critical_slowing_down(delta_trajectory, window=50):
    """
    Metric 10.3: Critical Slowing Down (CSD).

    CSD = Corr(Δ_{t-1}, Δ_t) over 50-step sliding window

    Glossary: values approaching 1.0 indicate phase boundary crystallization.

    Input:  delta_trajectory: 1D array of Friction Delta values over training steps
    Output: scalar (CSD over last `window` steps)
    """
    delta = np.asarray(delta_trajectory, dtype=np.float32)
    if len(delta) < 3:
        return 0.0
    # use last `window` steps
    delta = delta[-window:]
    if len(delta) < 3:
        return 0.0
    x = delta[:-1]
    y = delta[1:]
    if np.std(x) < 1e-12 or np.std(y) < 1e-12:
        return 0.0
    return float(np.corrcoef(x, y)[0, 1])


# ---- Section 9: Anisotropic / Subspace ----

def anova_subspace_residual_norm(h, n_positional=8):
    """
    Metric 9.1: ANOVA Subspace Decomposition (residual norm).

    Decomposes h into:
        h = μ + pos_t + ctx_c + resid_{c,t}

    Returns the relative residual norm:
        ||resid||^2 / ||h||^2

    Glossary target: < 0.10 (clean position/context separation).

    Simplified implementation: uses position index as the positional factor
    and assumes a single context (single prompt). With one context, ctx_c = 0,
    so h - μ - pos_t = resid.

    Input:  h [n_tokens, n_layers, d_model]
    Output: scalar (relative residual norm per layer, averaged)
    """
    h = _to_float(h)
    n_tok, n_layers, d = h.shape
    rel_resid = np.zeros(n_layers)
    for l in range(n_layers):
        h_l = h[:, l, :]  # [n_tok, d]
        mu = h_l.mean(axis=0, keepdims=True)
        pos = h_l - mu  # residual after removing mean (single-context assumption)
        # fit linear position encoding to first n_positional components
        # (approximation: use PCA top-n_positional as "positional" subspace)
        try:
            u, s, vt = np.linalg.svd(pos, full_matrices=False)
            pos_proj = u[:, :n_positional] @ np.diag(s[:n_positional]) @ vt[:n_positional]
            resid = h_l - mu - pos_proj
            rel_resid[l] = np.sum(resid ** 2) / (np.sum((h_l - mu) ** 2) + 1e-12)
        except np.linalg.LinAlgError:
            rel_resid[l] = 0.0
    return float(np.mean(rel_resid))


# ---- Section 3.11: Effective Warning Lead Time ----

def effective_warning_lead_time(R_within, threshold=0.8, max_horizon=80):
    """
    Metric 3.11: Effective Warning Lead Time τ_eff.

    τ_eff = t_collapse - t_detection

    Glossary target: ≥ +30.0 tokens (MASSIF achieves mean +32.4).

    Here we adapt: t_detection = first token where σ_t (or its surrogate)
    rises above 0.35. t_collapse = first token where R_within crosses threshold.

    Returns the lead time in tokens. If no collapse, returns +max_horizon.
    If detection comes after collapse, returns negative.
    """
    R_within = _to_float(R_within)
    if R_within.ndim == 2:
        R_mean = np.nanmean(R_within, axis=1)
    else:
        R_mean = R_within
    valid = ~np.isnan(R_mean)
    if not np.any(valid):
        return float(max_horizon)
    # collapse: first token where R crosses threshold
    above = np.where(valid & (R_mean >= threshold))[0]
    if len(above) == 0:
        return float(max_horizon)
    t_collapse = int(above[0])
    # detection: first token where derivative exceeds 0.05 (proxy for σ_t > 0.35)
    dR = np.diff(R_mean)
    detect = np.where(dR > 0.05)[0]
    if len(detect) == 0:
        return float(max_horizon)  # no precursor detected
    t_detection = int(detect[0])
    return float(t_collapse - t_detection)


# ============================================================
# Master: compute all features for one prompt
# ============================================================

def compute_all_features(h, window_k=4, window_m=3, top_k=10,
                          R_threshold=0.8, max_horizon=20,
                          layer_band_splits=None, head_outputs=None,
                          h_runs=None):
    """
    Compute the full MASSIF feature family for one prompt.

    Input:
        h: [n_tokens, n_layers, d_model] hidden states (numpy or torch, bf16 OK)
        head_outputs: optional [n_tokens, n_layers, n_heads, head_dim]
                      If provided, computes the CANONICAL H*L surrogate R_t.
        h_runs: optional [N_runs, n_tokens, n_layers, d_model]
                If provided, computes the CANONICAL multi-run ensemble R_t.

    Returns:
        feature_dict: {feature_name: scalar}  — one scalar per prompt.
        Per-layer arrays are reduced to scalars via standard aggregations
        (mean, std, min, max, last, slope).

    R_t priority:
        1. h_runs (canonical multi-run)  -> R_canonical_multi_run features
        2. head_outputs (canonical H*L)  -> R_canonical_heads features
        3. velocity-corrected surrogates -> R_cross / R_within features
        All three are computed and stored under different feature prefixes
        so we can directly compare which ensemble carries the signal.
    """
    h = _to_float(h)
    n_tok, n_layers, d = h.shape

    # === Per-layer sequence features ===
    I = persistence_per_layer(h)              # [n_tok-1, n_layers]
    sigma = sigma_t_per_layer(I, window_k)   # same shape, NaN at start
    phi = phi_t_per_layer(sigma)
    psi = psi_t_per_layer(phi, window_m)
    kappa = kappa_t_per_layer(h)              # [n_tok-2, n_layers]

    # === R_t (Kuramoto) ===
    # Note: R_cross and R_within here are the VELOCITY-CORRECTED SURROGATES
    # (ensemble = layers / past-tokens, but vector = unit velocity).
    # The canonical R_t (multi-run or H*L) is computed below if inputs are provided.
    R_cross = R_t_cross_layer(h)              # [n_tok-1]  (velocity-corrected surrogate)
    R_within = R_t_within_trajectory(h, window_k)  # [n_tok-1, n_layers]
    V_cross, A_cross = velocity_acceleration(R_cross)
    V_within, A_within = velocity_acceleration(R_within)

    # === Canonical R_t variants (computed if optional inputs provided) ===
    R_heads = None
    R_multi_run = None
    if head_outputs is not None:
        try:
            R_heads = R_t_kuramoto_heads(head_outputs)  # [n_tok-1, n_layers]
        except Exception as e:
            print(f"[warn] R_t_kuramoto_heads failed: {e}")
    if h_runs is not None:
        try:
            R_multi_run = R_t_kuramoto_multi_run(h_runs)  # [n_tok-1, n_layers]
        except Exception as e:
            print(f"[warn] R_t_kuramoto_multi_run failed: {e}")

    # === Eigenvalue spectrum ===
    eig = covariance_eigenvalue_features(h, top_k=top_k)

    # === tau_collapse ===
    tau = tau_collapse_horizon(R_within, threshold=R_threshold, max_horizon=max_horizon)

    # === Aggregations to scalar ===
    def _agg(name, arr, prefix=""):
        out = {}
        if arr is None or arr.size == 0:
            return out
        arr_clean = arr[~np.isnan(arr)] if arr.dtype.kind == "f" else arr
        if arr_clean.size == 0:
            return out
        out[f"{prefix}{name}_mean"] = float(np.mean(arr_clean))
        out[f"{prefix}{name}_std"] = float(np.std(arr_clean)) if arr_clean.size > 1 else 0.0
        out[f"{prefix}{name}_min"] = float(np.min(arr_clean))
        out[f"{prefix}{name}_max"] = float(np.max(arr_clean))
        out[f"{prefix}{name}_last"] = float(arr_clean[-1])
        if arr_clean.size >= 2:
            out[f"{prefix}{name}_slope"] = float(np.polyfit(np.arange(arr_clean.size), arr_clean, 1)[0])
        else:
            out[f"{prefix}{name}_slope"] = 0.0
        return out

    feats = {}
    # Per-layer features (aggregated across layers AND tokens)
    feats.update(_agg("I", I))
    feats.update(_agg("sigma", sigma))
    feats.update(_agg("phi", phi))
    feats.update(_agg("psi", psi))
    feats.update(_agg("kappa", kappa))

    # R_t cross-layer (1D over time, velocity-corrected surrogate)
    feats.update(_agg("R_cross", R_cross))
    feats.update(_agg("V_cross", V_cross))
    feats.update(_agg("A_cross", A_cross))

    # R_t within trajectory (2D: time x layers, velocity-corrected surrogate)
    feats.update(_agg("R_within", R_within))
    feats.update(_agg("V_within", V_within))
    feats.update(_agg("A_within", A_within))

    # === CANONICAL R_t (H*L attention heads, single-run surrogate) ===
    # These are the features to report as "R_t^Kuramoto" per Metric 8.1.
    # Computed only if head_outputs was provided to compute_all_features.
    if R_heads is not None:
        V_heads, A_heads = velocity_acceleration(R_heads)
        feats.update(_agg("R_canonical_heads", R_heads))
        feats.update(_agg("V_canonical_heads", V_heads))
        feats.update(_agg("A_canonical_heads", A_heads))
        # tau_collapse using canonical R
        tau_heads = tau_collapse_horizon(R_heads, threshold=R_threshold, max_horizon=max_horizon)
        valid_tau_h = tau_heads[tau_heads >= 0]
        feats["tau_collapse_canonical_heads_min"] = float(np.min(valid_tau_h)) if valid_tau_h.size > 0 else float(max_horizon)
        feats["tau_collapse_canonical_heads_n_collapsed"] = int(np.sum(tau_heads == -1))

    # === CANONICAL R_t (multi-run ensemble, true ensemble) ===
    # Computed only if h_runs was provided. THIS is the canonical R_t.
    if R_multi_run is not None:
        V_mr, A_mr = velocity_acceleration(R_multi_run)
        feats.update(_agg("R_canonical_multirun", R_multi_run))
        feats.update(_agg("V_canonical_multirun", V_mr))
        feats.update(_agg("A_canonical_multirun", A_mr))
        tau_mr = tau_collapse_horizon(R_multi_run, threshold=R_threshold, max_horizon=max_horizon)
        valid_tau_mr = tau_mr[tau_mr >= 0]
        feats["tau_collapse_canonical_multirun_min"] = float(np.min(valid_tau_mr)) if valid_tau_mr.size > 0 else float(max_horizon)
        feats["tau_collapse_canonical_multirun_n_collapsed"] = int(np.sum(tau_mr == -1))

    # ============================================================
    # CANONICAL GLOSSARY METRICS (v5.0)
    # ============================================================

    # --- Section 2: SDE & Fokker-Planck Diagnostics ---
    # Use multi-run if available (canonical), else single-trajectory.
    sde_input = h_runs if h_runs is not None else h
    sde_axis = "token" if h_runs is not None else "layer"

    try:
        D1_vec, D1_norm = sde_drift_D1(sde_input, axis=sde_axis)
        D2_tr, D2_dir = sde_diffusion_D2(sde_input, axis=sde_axis)
        D4 = sde_D4(sde_input, axis=sde_axis)
        R_pawula = pawula_ratio(D4, D2_dir)
        rho_sde = sde_snr(D1_norm, D2_tr)

        feats["canonical_D1_norm"] = float(D1_norm)
        feats["canonical_D2_tr"] = float(D2_tr)
        feats["canonical_D2_dir"] = float(D2_dir)
        feats["canonical_D4"] = float(D4)
        feats["canonical_pawula_ratio"] = float(R_pawula)
        feats["canonical_sde_snr"] = float(rho_sde)
        # Regime classification per glossary
        feats["canonical_sde_regime"] = 1 if rho_sde > 1.5 else 0  # 1=BALLISTIC, 0=STOCHASTIC
        # Pawula regime
        feats["canonical_pawula_ok"] = int(6.0 <= R_pawula <= 50.0)
    except Exception as e:
        # SDE metrics may fail on degenerate inputs
        feats["_sde_error"] = str(e)

    # --- Section 3.1-3.4: Canonical layer-direction kinematics ---
    try:
        v_layer = v_layer_direction(h)              # [n_tok, L-1, d]
        a_layer = a_layer_direction(v_layer)         # [n_tok, L-2, d]
        kappa_canon = curvature_canonical(v_layer, a_layer)  # [n_tok, L-2]
        jerk_canon = jerk_canonical(kappa_canon)    # [n_tok, L-3]

        feats.update(_agg("canonical_v_layer", v_layer))
        feats.update(_agg("canonical_a_layer", a_layer))
        feats.update(_agg("canonical_kappa", kappa_canon))
        feats.update(_agg("canonical_jerk", jerk_canon))
    except Exception as e:
        feats["_kinematics_error"] = str(e)

    # --- Section 3.5: Layer-direction Persistence I_t ---
    try:
        I_layer_dir = persistence_layer_direction(v_layer)  # [n_tok-1, L-1]
        feats.update(_agg("canonical_I_layer_dir", I_layer_dir))
        # rolling persistence (single-run surrogate of sigma_t)
        if I_layer_dir.shape[0] > window_k:
            rolling_I = np.zeros_like(I_layer_dir)
            rolling_I[:window_k] = np.nan
            for t in range(window_k, I_layer_dir.shape[0]):
                rolling_I[t] = np.mean(I_layer_dir[t - window_k:t], axis=0)
            feats.update(_agg("canonical_I_layer_dir_rolling", rolling_I))
    except Exception as e:
        feats["_I_layer_error"] = str(e)

    # --- Section 3.6: Canonical multi-run sigma_t ---
    if h_runs is not None:
        try:
            # compute per-run I_layer_dir
            I_runs = []
            for r in range(h_runs.shape[0]):
                h_r = h_runs[r]
                v_r = v_layer_direction(h_r)
                I_r = persistence_layer_direction(v_r)
                I_runs.append(I_r)
            sigma_canon = sigma_t_canonical_multirun(I_runs, window_k=window_k)
            feats.update(_agg("canonical_sigma_t_multirun", sigma_canon))
            # max sigma_t (glossary: > 0.35 predicts collapse 2-3 steps ahead)
            valid_sigma = sigma_canon[~np.isnan(sigma_canon)]
            if valid_sigma.size > 0:
                feats["canonical_sigma_t_max"] = float(np.max(valid_sigma))
                feats["canonical_sigma_t_above_035"] = int(np.any(valid_sigma > 0.35))
        except Exception as e:
            feats["_sigma_multirun_error"] = str(e)

    # --- Section 3.9: Cross-token Directional Coherence c_l ---
    try:
        # use layer-direction velocity as input
        c_l = cross_token_coherence(v_layer)
        feats.update(_agg("canonical_c_l", c_l))
        feats["canonical_c_l_max"] = float(np.max(c_l)) if len(c_l) > 0 else 0.0
        feats["canonical_collective_alignment"] = int(np.any(c_l > 0.8))
    except Exception as e:
        feats["_c_l_error"] = str(e)

    # --- Section 5.1, 5.2, 5.3, 5.4: Attention head metrics ---
    if head_outputs is not None:
        try:
            C, theta, head_var = coherence_C(head_outputs)
            feats["canonical_coherence_C"] = float(C)
            feats["canonical_coherence_theta"] = float(theta)
            feats.update(_agg("canonical_head_var", head_var))

            sigma_head_sq, kappa_per_head = fiber_curvature_sigma_head_sq(head_outputs)
            feats.update(_agg("canonical_sigma_head_sq", sigma_head_sq))
            feats["canonical_sigma_head_sq_min"] = float(np.min(sigma_head_sq)) if sigma_head_sq.size > 0 else 0.0
            feats["canonical_heads_collapsed"] = int(np.any(sigma_head_sq < 0.50))

            decoup_v = decoupling_velocity(sigma_head_sq)
            feats.update(_agg("canonical_decoupling_vel", decoup_v))
            feats["canonical_hidden_descent_active"] = int(np.any(np.nanmean(decoup_v, axis=0) > 0.005))

            attn_entropy_var = attention_entropy_variance(head_outputs)
            feats["canonical_attn_entropy_var"] = float(attn_entropy_var)

            # Dubito score (Metric 3.10) — combine sigma_head_sq, kappa, C
            try:
                kappa_mean_per_pos = np.nanmean(kappa_per_head, axis=-1)  # [n_tok-2, n_layers]
                # broadcast C and sigma_head_sq
                dubito = dubito_score(sigma_head_sq, kappa_mean_per_pos, C)
                feats.update(_agg("canonical_dubito_score", dubito))
                feats["canonical_dubito_max"] = float(np.nanmax(dubito)) if dubito.size > 0 else 0.0
                feats["canonical_dubito_above_7"] = int(np.any(dubito > 7.0))
            except Exception as e:
                feats["_dubito_error"] = str(e)
        except Exception as e:
            feats["_head_metrics_error"] = str(e)

    # --- Section 5.5: Spectral Concentration ---
    try:
        S_conc = spectral_concentration(h, top_k=16)
        feats.update(_agg("canonical_spectral_concentration", S_conc))
        feats["canonical_spectral_concentration_max"] = float(np.max(S_conc)) if len(S_conc) > 0 else 0.0
        feats["canonical_dimensional_collapse"] = int(np.any(S_conc > 0.15))
    except Exception as e:
        feats["_spectral_conc_error"] = str(e)

    # --- Section 10.1, 10.2, 10.3: MASSIF Training-Time Stability Observatory ---
    try:
        basin_r = basin_radius(h, max_tokens=64)
        feats["canonical_basin_radius"] = float(basin_r)
    except Exception as e:
        feats["_basin_error"] = str(e)

    try:
        lambda_N = norm_growth_rate(h, max_tokens=64)
        feats["canonical_norm_growth_rate"] = float(lambda_N)
        feats["canonical_norm_shrinking"] = int(lambda_N < 0.0)
    except Exception as e:
        feats["_norm_growth_error"] = str(e)

    try:
        # CSD requires per-step Friction Delta. Compute it over time.
        # Friction Delta per token: V_early - V_late using canonical L/2 split
        var_per_token_layer = np.var(h, axis=-1)  # [n_tok, n_layers]
        n_layers = h.shape[1]
        split = n_layers // 2
        if split > 0:
            V_early_per_tok = np.mean(var_per_token_layer[:, :split], axis=1)
            V_late_per_tok = np.mean(var_per_token_layer[:, split:], axis=1)
            delta_traj = V_early_per_tok - V_late_per_tok
            csd = critical_slowing_down(delta_traj, window=50)
            feats["canonical_csd"] = float(csd)
            feats["canonical_phase_boundary"] = int(csd > 0.9)
    except Exception as e:
        feats["_csd_error"] = str(e)

    # --- Section 4.3: CFKR Trigger ---
    try:
        # use canonical friction delta (L/2 split) and I_t (last layer)
        if split > 0:
            delta_canonical = float(np.mean(V_early_per_tok) - np.mean(V_late_per_tok))
            # I_t at last layer, mean over tokens
            I_t_last = float(np.nanmean(I_layer_dir[:, -1])) if 'I_layer_dir' in dir() else 0.0
            feats["canonical_cfkr_trigger"] = cfkr_trigger(delta_canonical, I_t_last)
    except Exception as e:
        feats["_cfkr_error"] = str(e)

    # --- Section 3.11: Effective Warning Lead Time ---
    try:
        if R_within is not None:
            tau_eff = effective_warning_lead_time(R_within, threshold=R_threshold, max_horizon=max_horizon)
            feats["canonical_tau_eff_lead_time"] = float(tau_eff)
    except Exception as e:
        feats["_tau_eff_error"] = str(e)

    # --- Section 9.1: ANOVA Subspace Residual ---
    try:
        anova_resid = anova_subspace_residual_norm(h, n_positional=8)
        feats["canonical_anova_residual"] = float(anova_resid)
        feats["canonical_subspace_clean"] = int(anova_resid < 0.10)
    except Exception as e:
        feats["_anova_error"] = str(e)

    # Eigenvalue features (per-layer arrays)
    for k in ["eig_lambda1", "eig_lambda2", "eig_lambda1_minus_lambda2",
              "eig_spectral_entropy", "eig_participation_ratio",
              "eig_effective_rank", "eig_trace"]:
        feats.update(_agg(k, eig[k]))

    # Top-k eigenvalues: aggregate each rank across layers
    topk_arr = eig["eig_topk"]  # [n_layers, top_k]
    for rank in range(topk_arr.shape[1]):
        feats.update(_agg(f"eig_rank{rank}", topk_arr[:, rank]))

    # tau_collapse
    valid_tau = tau[tau >= 0]
    feats["tau_collapse_mean"] = float(np.mean(valid_tau)) if valid_tau.size > 0 else float(max_horizon)
    feats["tau_collapse_min"] = float(np.min(valid_tau)) if valid_tau.size > 0 else float(max_horizon)
    feats["tau_collapse_n_collapsed"] = int(np.sum(tau == -1))
    feats["tau_collapse_n_stable"] = int(np.sum(tau == max_horizon))

    # === Friction Delta (variance-only) for direct comparison with null pilot ===
    # Compute the original Friction Delta features too, so we can compare
    # directly with the null result.
    # h: [n_tok, n_layers, d]
    # Var over d for each (token, layer)
    var_per_token_layer = np.var(h, axis=-1)  # [n_tok, n_layers]
    # then mean over tokens
    V_per_layer = np.mean(var_per_token_layer, axis=0)  # [n_layers]
    # for each split point s: V_early = mean(V_per_layer[:s]), V_late = mean(V_per_layer[s:])
    n = len(V_per_layer)
    splits = layer_band_splits or list(range(2, n - 1, max(1, (n - 3) // 7)))[:7]
    for i_s, s in enumerate(splits):
        if s < 1 or s >= n:
            continue
        V_early = float(np.mean(V_per_layer[:s]))
        V_late = float(np.mean(V_per_layer[s:]))
        feats[f"delta_split{s}"] = V_early - V_late
        feats[f"delta_abs_split{s}"] = abs(V_early - V_late)
        feats[f"V_early_split{s}"] = V_early
        feats[f"V_late_split{s}"] = V_late

    feats["_n_tokens"] = int(n_tok)
    feats["_n_layers"] = int(n_layers)
    feats["_d_model"] = int(d)

    return feats


# ============================================================
# Sanity test
# ============================================================

if __name__ == "__main__":
    print("Running sanity test...")
    np.random.seed(0)
    # simulate: 30 tokens, 12 layers, 64 dim
    h = np.random.randn(30, 12, 64).astype(np.float32)
    # add some structure: layer 6 always aligned
    h[:, 6, :] = np.random.randn(64).astype(np.float32) * 0.1 + 1.0

    # Also test canonical H*L R_t: simulate per-head outputs
    # 30 tokens, 12 layers, 8 heads, 8 head_dim (= 64 total = d_model)
    head_outputs = np.random.randn(30, 12, 8, 8).astype(np.float32)
    # inject synchronization: at t=15..20, all heads at layer 3 point the same direction
    sync_dir = np.random.randn(8).astype(np.float32)
    sync_dir /= np.linalg.norm(sync_dir) + 1e-8
    head_outputs[15:20, 3, :, :] = sync_dir[None, :] * 5.0

    # Also test canonical multi-run R_t: 5 runs of the same prompt
    h_runs = np.random.randn(5, 30, 12, 64).astype(np.float32)
    # inject synchronization: at t=10..15, all 5 runs move in the same direction
    sync_v = np.random.randn(64).astype(np.float32)
    for r in range(5):
        h_runs[r, 10:15, :, :] += sync_v[None, None, :] * 2.0

    feats = compute_all_features(h, head_outputs=head_outputs, h_runs=h_runs)
    print(f"Computed {len([k for k in feats if not k.startswith('_')])} features")
    # Show only R_canonical_* features (the new ones)
    print("\n--- CANONICAL R_t features (NEW) ---")
    for k in sorted(feats.keys()):
        if "canonical" in k:
            v = feats[k]
            if isinstance(v, (int, np.integer)):
                print(f"  {k:50s} = {v}")
            else:
                print(f"  {k:50s} = {v:+.4f}")
    print("\n--- Velocity-corrected surrogate R_t features ---")
    for k in sorted(feats.keys()):
        if k.startswith("R_cross") or k.startswith("R_within"):
            if "canonical" not in k:
                print(f"  {k:50s} = {feats[k]:+.4f}")
