"""
analysis_b_dynamical_classes.py
===============================

Analysis B: Per-prompt dynamical class assignment (Zenodo 20542872).

Tests whether the four dynamical classes — Accelerator / Decelerator / Neutral /
Instant — defined by the sign of V_t (synchronization velocity) BEFORE a
collapse event predict which prompts hallucinate.

This is the cross-product that ties the two programs together:
  - MASSIF [20542872] defined the classes for RECURSIVE collapse (prompt topology)
  - Here we ask whether the SAME classes predict HALLUCINATION under factual
    (TruthfulQA) forcing

Adaptation for single-trajectory data:
  - "Collapse event" = generation step where within-trajectory R_t crosses
    threshold (synchronization -> attractor lock-in)
  - V_t sign computed over the last 5 steps BEFORE the collapse event
    (or over the last 5 steps if no collapse)
  - "Instant" class: collapse at step 1 (no precursor) OR no measurable V_t

Statistical tests:
  (T1) Hallucination rate by dynamical class (chi-square or Fisher's exact)
  (T2) Per-class AUROC: does class membership alone predict hallucination?
  (T3) Within-hallucinated subset: does V_t sign predict the POSITION of
       hallucination onset (matched against judge-confirmed labels)?
  (T4) Cross-model: is the class distribution stable across the 3 models?
       (consistency check that the classes are a model-level property, not noise)

Output:
    /path/to/massif_hidden_states/<model_slug>/analysis_b/
        per_prompt_classes.csv     # one row per prompt with class + R_t trajectory stats
        class_summary.csv          # class x hallucination contingency table
        statistical_tests.json
        figures/                   # R_t trajectory plots by class
"""

import os
import sys
import json
import argparse
import warnings
from pathlib import Path
from typing import Dict, List, Tuple, Optional

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

# Make the MASSIF feature library importable
# Works both when run as a .py script and when pasted into a notebook cell.
try:
    _this_dir = Path(__file__).resolve().parent
except NameError:
    # Notebook: __file__ is not defined; use CWD or a fallback
    _this_dir = Path.cwd()
    if not (_this_dir / "massif_features.py").exists():
        for candidate in [
            Path("/content/massif_pipeline/massif_features.py"),
            Path("/content/massif_features.py"),
            Path("/content/massif_hidden_states_pipeline/massif_features.py"),
            Path("/content/drive/MyDrive/massif_hidden_states_pipeline/massif_features.py"),
            Path("/content/drive/MyDrive/massif_pipeline/massif_features.py"),
        ]:
            if candidate.exists():
                _this_dir = candidate.parent
                break

if str(_this_dir) not in sys.path:
    sys.path.insert(0, str(_this_dir))
from massif_features import (
    persistence_per_layer, sigma_t_per_layer,
    R_t_cross_layer, R_t_within_trajectory,
    velocity_acceleration, tau_collapse_horizon,
    _to_float,
)

# Print version on startup so you always know which version is running
try:
    from VERSION import print_version
    print_version()
except ImportError:
    pass


# ============================================================
# Dynamical class assignment
# ============================================================
# (Zenodo 20542872)
#
# Classes (originally defined for recursive collapse):
#   Accelerator (V_t > 0): synchronization builds before flip
#   Decelerator (V_t < 0): synchronization peaks then decelerates into flip
#   Neutral     (V_t ~ 0): flip independent of synchronization
#   Instant     (no precursor): flip at step 1, no measurable warning
#
# Phi-2 anomaly (Zenodo 20542872): near-zero V_t with highly variable
# flip times. We retain a "Stochastic" subclass for prompts that don't
# fit cleanly into any of the four.

CLASS_NAMES = ["Accelerator", "Decelerator", "Neutral", "Instant", "Stochastic"]


def find_collapse_event(R_within: np.ndarray, threshold: float = 0.8) -> Optional[int]:
    """
    Find the first token position where R_within (mean across layers)
    crosses `threshold`.

    R_within: [n_tokens, n_layers]
    Returns: int token position, or None if no collapse.
    """
    if R_within.ndim == 1:
        R_mean = R_within
    else:
        # nanmean across layers
        with np.errstate(all="ignore"):
            R_mean = np.nanmean(R_within, axis=1)
    valid = ~np.isnan(R_mean)
    if not np.any(valid):
        return None
    above = np.where(valid & (R_mean >= threshold))[0]
    if len(above) == 0:
        return None
    return int(above[0])


def assign_dynamical_class(h: np.ndarray, threshold: float = 0.8,
                             v_window: int = 5, v_eps: float = 0.005) -> dict:
    """
    Assign one of the four (or five) dynamical classes to a single prompt's
    hidden-state trajectory.

    Logic:
      1. Compute R_cross (over layers) and R_within (over tokens, sliding window).
      2. Find collapse event = first token where R_within (mean across layers)
         crosses `threshold`.
      3. If collapse at step <= 1: class = "Instant"
      4. Else compute V_t = slope of R_within over the last `v_window` steps
         BEFORE the collapse event.
         - V > v_eps  -> "Accelerator"
         - V < -v_eps -> "Decelerator"
         - |V| <= v_eps -> "Neutral"
      5. If no collapse: compute V_t over the last v_window steps.
         If |V| <= v_eps AND R never exceeded threshold*0.7 -> "Stochastic"
         (Phi-2-like regime; near-zero velocity with no clear collapse)
         Else: classify by V_t sign as above (just no collapse event)

    Returns dict with all the intermediate quantities for downstream analysis.
    """
    h = _to_float(h)
    n_tok, n_layers, d = h.shape

    R_cross = R_t_cross_layer(h)              # [n_tok]
    R_within = R_t_within_trajectory(h, window_k=4)  # [n_tok, n_layers]
    V_cross, A_cross = velocity_acceleration(R_cross)
    V_within, A_within = velocity_acceleration(R_within)

    # mean R_within across layers (ignoring NaNs)
    with np.errstate(all="ignore"):
        R_within_mean = np.nanmean(R_within, axis=1)  # [n_tok]
        V_within_mean = np.nanmean(V_within, axis=1)

    # find collapse event
    collapse_pos = find_collapse_event(R_within, threshold)

    # compute V_t over the last v_window steps BEFORE collapse (or before end)
    if collapse_pos is not None and collapse_pos > 1:
        end = collapse_pos
        start = max(1, end - v_window)
    else:
        end = len(R_within_mean)
        start = max(1, end - v_window)

    valid_idx = ~np.isnan(R_within_mean[start:end])
    if valid_idx.sum() >= 2:
        x = np.arange(start, end)[valid_idx]
        y = R_within_mean[start:end][valid_idx]
        V_slope = float(np.polyfit(x, y, 1)[0])
    else:
        V_slope = 0.0

    # class assignment
    if collapse_pos is not None and collapse_pos <= 1:
        cls = "Instant"
    elif collapse_pos is None:
        # no collapse
        max_R = float(np.nanmax(R_within_mean)) if np.any(~np.isnan(R_within_mean)) else 0.0
        if abs(V_slope) <= v_eps and max_R < threshold * 0.7:
            cls = "Stochastic"
        elif V_slope > v_eps:
            cls = "Accelerator"
        elif V_slope < -v_eps:
            cls = "Decelerator"
        else:
            cls = "Neutral"
    else:
        if V_slope > v_eps:
            cls = "Accelerator"
        elif V_slope < -v_eps:
            cls = "Decelerator"
        else:
            cls = "Neutral"

    # tau_collapse horizon (per-layer)
    tau = tau_collapse_horizon(R_within, threshold=threshold, max_horizon=20)

    return {
        "class": cls,
        "collapse_pos": collapse_pos if collapse_pos is not None else -1,
        "V_slope_pre_collapse": V_slope,
        "R_cross_mean": float(np.nanmean(R_cross)),
        "R_cross_max": float(np.nanmax(R_cross)),
        "R_cross_last": float(R_cross[-1]),
        "R_within_mean": float(np.nanmean(R_within_mean)),
        "R_within_max": float(np.nanmax(R_within_mean)) if np.any(~np.isnan(R_within_mean)) else 0.0,
        "R_within_last": float(R_within_mean[~np.isnan(R_within_mean)][-1]) if np.any(~np.isnan(R_within_mean)) else 0.0,
        "V_cross_mean": float(np.nanmean(V_cross)),
        "A_cross_mean": float(np.nanmean(A_cross)),
        "V_within_mean": float(np.nanmean(V_within)),
        "tau_collapse_min": int(np.min(tau[tau >= 0])) if np.any(tau >= 0) else 20,
        "tau_collapse_mean": float(np.mean(tau[tau >= 0])) if np.any(tau >= 0) else 20.0,
        "n_collapsed_layers": int(np.sum(tau == -1)),
        "n_stable_layers": int(np.sum(tau == 20)),
    }


# ============================================================
# Per-model analysis
# ============================================================

def analyze_model(model_dir: Path, min_overlap: int = 2) -> dict:
    slug = model_dir.name
    print(f"\n{'='*70}\nAnalysis B: {slug}\n{'='*70}")

    out_dir = model_dir / "analysis_b"
    out_dir.mkdir(exist_ok=True)
    fig_dir = out_dir / "figures"
    fig_dir.mkdir(exist_ok=True)

    # Load — try importing from analysis_a_massif; if that fails (because
    # the module isn't on sys.path in a notebook context), fall back to
    # loading it directly from the same directory as this script.
    try:
        from analysis_a_massif import load_model_data, ensure_judge_labels
    except ImportError:
        # Use the same _this_dir that was resolved at module load time
        # (top of file). It already points to the directory containing
        # both analysis_a_massif.py and this script.
        aap_path = _this_dir / "analysis_a_massif.py"
        if not aap_path.exists():
            # Last-resort: search common locations
            for candidate in [
                Path("/content/massif_pipeline/analysis_a_massif.py"),
                Path("/content/massif_hidden_states_pipeline/analysis_a_massif.py"),
                Path("/content/drive/MyDrive/massif_hidden_states_pipeline/analysis_a_massif.py"),
                Path("/content/drive/MyDrive/massif_pipeline/analysis_a_massif.py"),
                Path("/content/analysis_a_massif.py"),
            ]:
                if candidate.exists():
                    aap_path = candidate
                    break
        if not aap_path.exists():
            raise FileNotFoundError(
                f"Could not find analysis_a_massif.py. Searched: {_this_dir}, "
                f"/content/massif_pipeline/, /content/massif_hidden_states_pipeline/, "
                f"/content/drive/MyDrive/massif_hidden_states_pipeline/, /content/"
            )
        if str(aap_path.parent) not in sys.path:
            sys.path.insert(0, str(aap_path.parent))
        import importlib.util
        spec = importlib.util.spec_from_file_location("analysis_a_massif", str(aap_path))
        aap = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(aap)
        load_model_data = aap.load_model_data
        ensure_judge_labels = aap.ensure_judge_labels
        print(f"[load] using analysis_a_massif from {aap_path}")

    hidden_states, meta = load_model_data(model_dir)
    records = meta["records"]

    # Labels — thread min_overlap through, but be defensive: if the loaded
    # analysis_a_massif is an older version that doesn't accept min_overlap,
    # fall back to the old signature (without the parameter) and warn.
    import inspect
    _sig = inspect.signature(ensure_judge_labels)
    if "min_overlap" in _sig.parameters:
        labels = ensure_judge_labels(meta, model_dir, groq_key=None,
                                       re_judge=False, min_overlap=min_overlap)
    else:
        # Old version of analysis_a_massif.py — doesn't support min_overlap
        print(f"[warn] loaded analysis_a_massif.py doesn't support min_overlap parameter")
        print(f"[warn] (using cached labels or re-judging with default strict threshold)")
        print(f"[warn] To fix: re-download v3.1.1 tarball and replace analysis_a_massif.py")
        labels = ensure_judge_labels(meta, model_dir, groq_key=None, re_judge=False)
    print(f"[load] {len(records)} prompts, {meta['n_layers']} layers")

    # Class assignment per prompt
    print("[class] assigning dynamical classes...")
    rows = []
    for i, (h, lbl) in enumerate(zip(hidden_states, labels)):
        h_arr = _to_float(h)
        info = assign_dynamical_class(h_arr)
        info["prompt_id"] = records[i]["id"]
        info["label"] = lbl
        info["n_tokens"] = records[i]["n_tokens"]
        info["is_halluc"] = int(lbl == "FALSE")
        info["is_valid"] = int(lbl in ("TRUE", "FALSE"))
        rows.append(info)
    df = pd.DataFrame(rows)
    df.to_csv(out_dir / "per_prompt_classes.csv", index=False)
    print(f"[class] distribution:\n{df['class'].value_counts().to_string()}")

    # Filter to valid labels
    valid = df[df["is_valid"] == 1].copy()
    n_valid = len(valid)
    if n_valid < 20:
        print(f"[skip] only {n_valid} valid labels")
        return {"slug": slug, "n_valid": n_valid, "skipped": True}

    # === T1: Contingency table class x hallucination ===
    print("\n[T1] Contingency table (class x hallucination):")
    ct = pd.crosstab(valid["class"], valid["is_halluc"], margins=True)
    print(ct.to_string())
    ct.to_csv(out_dir / "class_summary.csv")

    # Chi-square or Fisher's exact
    ct_no_margin = pd.crosstab(valid["class"], valid["is_halluc"]).values
    stats = {}
    try:
        if ct_no_margin.shape == (2, 2):
            # Fisher's exact for 2x2
            from scipy.stats import fisher_exact
            odds, p = fisher_exact(ct_no_margin)
            stats["fisher_odds_ratio"] = float(odds)
            stats["fisher_p"] = float(p)
            print(f"[T1] Fisher's exact: OR={odds:.3f}, p={p:.4f}")
        else:
            from scipy.stats import chi2_contingency
            chi2, p, dof, expected = chi2_contingency(ct_no_margin)
            stats["chi2"] = float(chi2)
            stats["chi2_p"] = float(p)
            stats["chi2_dof"] = int(dof)
            print(f"[T1] Chi-square: chi2={chi2:.3f}, dof={dof}, p={p:.4f}")

        # Per-class hallucination rate
        per_class = []
        for cls in CLASS_NAMES:
            sub = valid[valid["class"] == cls]
            if len(sub) == 0:
                per_class.append({"class": cls, "n": 0, "n_halluc": 0, "rate": 0.0})
                continue
            n_h = int(sub["is_halluc"].sum())
            per_class.append({
                "class": cls,
                "n": int(len(sub)),
                "n_halluc": n_h,
                "rate": float(n_h / len(sub)),
            })
            print(f"  {cls:15s} n={len(sub):3d}  halluc_rate={n_h/len(sub):.3f}")
        pd.DataFrame(per_class).to_csv(out_dir / "per_class_rates.csv", index=False)
    except Exception as e:
        print(f"[T1 err] {e}")
        import traceback; traceback.print_exc()

    # === T2: Per-class AUROC (one-vs-rest) ===
    print("\n[T2] Per-class AUROC (class membership -> hallucination):")
    from sklearn.metrics import roc_auc_score
    class_aurocs = {}
    for cls in CLASS_NAMES:
        n_cls = int((valid["class"] == cls).sum())
        if n_cls == 0 or n_cls == len(valid):
            class_aurocs[cls] = 0.5
            continue
        score = (valid["class"] == cls).astype(int).values
        try:
            a = float(roc_auc_score(valid["is_halluc"].values, score))
            class_aurocs[cls] = a
            print(f"  {cls:15s} AUROC={a:.4f}  (n={n_cls})")
        except Exception:
            class_aurocs[cls] = 0.5
    stats["per_class_auroc"] = class_aurocs

    # === T3: V_slope_pre_collapse AUROC for hallucination ===
    print("\n[T3] V_slope_pre_collapse as continuous predictor:")
    v_slope = valid["V_slope_pre_collapse"].values
    y = valid["is_halluc"].values
    try:
        a_high = float(roc_auc_score(y, v_slope))
        a_low = 1 - a_high
        a_max = max(a_high, a_low)
        direction = "high->halluc" if a_high > a_low else "low->halluc"
        print(f"  V_slope AUROC (high)={a_high:.4f}, (low)={a_low:.4f}, max={a_max:.4f} dir={direction}")
        stats["v_slope_auroc"] = a_max
        stats["v_slope_direction"] = direction
    except Exception as e:
        print(f"  [T3 err] {e}")

    # === T4: tau_collapse_min AUROC ===
    print("\n[T4] tau_collapse_min as predictor:")
    tau = valid["tau_collapse_min"].values
    try:
        a_high = float(roc_auc_score(y, tau))
        a_low = 1 - a_high
        a_max = max(a_high, a_low)
        direction = "high->halluc" if a_high > a_low else "low->halluc"
        print(f"  tau_collapse_min AUROC (high)={a_high:.4f}, (low)={a_low:.4f}, max={a_max:.4f} dir={direction}")
        stats["tau_auroc"] = a_max
        stats["tau_direction"] = direction
    except Exception as e:
        print(f"  [T4 err] {e}")

    # === T5: Cross-feature: V_slope AND tau_collapse together ===
    print("\n[T5] Combined LASSO on dynamical-class features:")
    try:
        from sklearn.linear_model import LogisticRegressionCV
        from sklearn.model_selection import StratifiedKFold
        from sklearn.preprocessing import StandardScaler
        from sklearn.pipeline import Pipeline

        dyn_feats = ["V_slope_pre_collapse", "R_cross_mean", "R_cross_max",
                     "R_within_mean", "R_within_max", "tau_collapse_min",
                     "tau_collapse_mean", "n_collapsed_layers", "n_stable_layers",
                     "V_cross_mean", "A_cross_mean"]
        X = valid[dyn_feats].values
        X = np.where(np.isnan(X), 0.0, X)
        if len(np.unique(y)) >= 2 and len(y) >= 10:
            pipe = Pipeline([
                ("scaler", StandardScaler()),
                ("clf", LogisticRegressionCV(
                    Cs=np.logspace(-3, 1, 10), penalty="l1", solver="liblinear",
                    cv=StratifiedKFold(n_splits=min(5, min(np.bincount(y)))),
                    scoring="roc_auc", max_iter=2000, random_state=42,
                )),
            ])
            skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
            aurocs = []
            for tr, te in skf.split(X, y):
                pipe.fit(X[tr], y[tr])
                p = pipe.predict_proba(X[te])[:, 1]
                aurocs.append(float(roc_auc_score(y[te], p)))
            dyn_lasso_auroc = float(np.mean(aurocs))
            print(f"  LASSO-CV AUROC = {dyn_lasso_auroc:.4f} +/- {np.std(aurocs):.4f}")
            stats["dyn_lasso_cv_auroc"] = dyn_lasso_auroc
            stats["dyn_lasso_cv_std"] = float(np.std(aurocs))
        else:
            print(f"  [T5 skip] insufficient samples (y unique={len(np.unique(y))}, n={len(y)})")
    except Exception as e:
        print(f"  [T5 err] {e}")
        import traceback; traceback.print_exc()

    # Save
    with open(out_dir / "statistical_tests.json", "w") as f:
        # convert numpy types
        def _conv(o):
            if isinstance(o, (np.integer,)):
                return int(o)
            if isinstance(o, (np.floating,)):
                return float(o)
            if isinstance(o, np.ndarray):
                return o.tolist()
            return o
        json.dump(stats, f, indent=2, default=_conv)

    # === Plots ===
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        # 1. R_within_mean trajectory by class
        fig, axes = plt.subplots(2, 3, figsize=(12, 6), sharex=False, sharey=False)
        axes = axes.flatten()
        for i, cls in enumerate(CLASS_NAMES):
            if i >= 6:
                break
            ax = axes[i]
            sub = valid[valid["class"] == cls]
            if len(sub) == 0:
                ax.set_title(f"{cls}\n(n=0)")
                continue
            # plot R_within_mean trajectory for each prompt in this class
            # (we don't have it stored — recompute quickly)
            for pid in sub["prompt_id"].values[:5]:  # show up to 5
                h_arr = _to_float(hidden_states[pid])
                R_w = R_t_within_trajectory(h_arr, window_k=4)
                with np.errstate(all="ignore"):
                    R_w_mean = np.nanmean(R_w, axis=1)
                ax.plot(np.arange(len(R_w_mean)), R_w_mean, alpha=0.4, lw=0.8)
            ax.axhline(0.8, color="red", linestyle="--", alpha=0.5, label="collapse thresh")
            ax.set_title(f"{cls}\n(n={len(sub)})")
            ax.set_xlabel("token step")
            ax.set_ylabel("R_within (mean across layers)")
            ax.set_ylim(0, 1.05)
        for j in range(len(CLASS_NAMES), 6):
            axes[j].axis("off")
        plt.tight_layout()
        plt.savefig(fig_dir / "R_within_by_class.png", dpi=120)
        plt.close()

        # 2. Hallucination rate by class bar plot
        rates = []
        for cls in CLASS_NAMES:
            sub = valid[valid["class"] == cls]
            if len(sub) > 0:
                rates.append({"class": cls, "rate": float(sub["is_halluc"].mean()), "n": len(sub)})
            else:
                rates.append({"class": cls, "rate": 0.0, "n": 0})
        rdf = pd.DataFrame(rates)
        fig, ax = plt.subplots(figsize=(7, 4))
        bars = ax.bar(rdf["class"], rdf["rate"], color="steelblue", edgecolor="black")
        for b, n in zip(bars, rdf["n"]):
            ax.text(b.get_x() + b.get_width()/2, b.get_height() + 0.02,
                    f"n={n}", ha="center", fontsize=9)
        overall = float(valid["is_halluc"].mean())
        ax.axhline(overall, color="red", linestyle="--", label=f"Overall = {overall:.3f}")
        ax.set_ylabel("Hallucination rate")
        ax.set_title(f"{slug}: Hallucination rate by dynamical class")
        ax.set_ylim(0, 1.0)
        ax.legend()
        plt.tight_layout()
        plt.savefig(fig_dir / "halluc_rate_by_class.png", dpi=120)
        plt.close()
    except Exception as e:
        print(f"[plot err] {e}")

    summary = {
        "slug": slug,
        "n_valid": n_valid,
        "n_halluc": int(valid["is_halluc"].sum()),
        "class_distribution": valid["class"].value_counts().to_dict(),
        "stats": stats,
    }
    with open(out_dir / "summary.json", "w") as f:
        json.dump(summary, f, indent=2, default=lambda o: int(o) if isinstance(o, np.integer) else float(o) if isinstance(o, np.floating) else o)
    print(f"\n[summary] {json.dumps(summary, indent=2, default=str)}")
    return summary


# ============================================================
# Cross-model comparison
# ============================================================

def cross_model_comparison(summaries: List[dict], data_dir: Path):
    """T4: Are class distributions stable across models?"""
    print("\n" + "=" * 70)
    print("CROSS-MODEL COMPARISON (T4)")
    print("=" * 70)
    rows = []
    for s in summaries:
        if s.get("skipped"):
            continue
        for cls, n in s["class_distribution"].items():
            rows.append({"model": s["slug"], "class": cls, "n": n})
    if not rows:
        print("[skip] no valid models")
        return
    df = pd.DataFrame(rows)
    pivot = df.pivot(index="model", columns="class", values="n").fillna(0).astype(int)
    pivot["total"] = pivot.sum(axis=1)
    print(pivot.to_string())
    pivot.to_csv(data_dir / "analysis_b_class_distribution.csv")

    # normalize to %
    pct = pivot.drop(columns="total").div(pivot["total"], axis=0) * 100
    print("\nPercentages:")
    print(pct.round(1).to_string())


# ============================================================
# Main
# ============================================================

def main(data_dir=None, models=None, min_overlap=2, **kwargs):
    """
    Entry point. Works BOTH as a CLI script AND as a direct call from a
    Jupyter/Colab notebook cell.

    Usage from CLI:
        python analysis_b_dynamical_classes.py --data-dir /content/drive/MyDrive/massif_hidden_states

    Usage from a notebook cell:
        # defaults (Colab Drive path, all 3 models)
        main()

        # custom data dir
        main(data_dir='/content/drive/MyDrive/massif_hidden_states')

        # subset of models
        main(models=['qwen25-1.5b'])

        # use loose judge threshold (matches Analysis A)
        main(min_overlap=1)
    """
    in_notebook = ("ipykernel" in sys.modules
                    or "google.colab" in sys.modules
                    or "IPython" in sys.modules)

    if not in_notebook:
        # CLI
        import argparse
        ap = argparse.ArgumentParser()
        ap.add_argument("--data-dir", default="/content/drive/MyDrive/massif_hidden_states")
        ap.add_argument("--models", nargs="+",
                        default=["qwen25-1.5b", "gemma2-2b-it", "llama32-1b-instruct"])
        ap.add_argument("--min-overlap", type=int, default=2,
                        help="Min content-token overlap with gold answer (1=loose, 2=strict)")
        args = ap.parse_args()
        if data_dir is None:
            data_dir = args.data_dir
        if models is None:
            models = args.models
        if min_overlap == 2:
            min_overlap = args.min_overlap

    # Notebook defaults
    if data_dir is None:
        data_dir = "/content/drive/MyDrive/massif_hidden_states"
    if models is None:
        models = ["qwen25-1.5b", "gemma2-2b-it", "llama32-1b-instruct"]

    data_dir = Path(data_dir)
    print(f"[main] data_dir = {data_dir}")
    print(f"[main] min_overlap = {min_overlap}")

    all_summaries = []
    for slug in models:
        mdir = data_dir / slug
        if not mdir.exists():
            print(f"[skip] {slug}: not found")
            continue
        try:
            s = analyze_model(mdir, min_overlap=min_overlap)
            all_summaries.append(s)
        except Exception as e:
            import traceback; traceback.print_exc()

    cross_model_comparison(all_summaries, data_dir)


if __name__ == "__main__":
    main()
