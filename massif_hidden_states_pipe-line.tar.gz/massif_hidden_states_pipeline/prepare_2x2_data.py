"""
prepare_2x2_data.py
===================

Prepares the input CSVs for two_by_two_permutation.py from the existing
cached data in the MASSIF hidden-states pipeline.

Outputs (per model):
  features_<model>.csv  — idx + 318 feature columns + n_tokens
  labels_<model>.csv    — idx + hardened + rule

The features and rule labels come from the current Analysis A run
(features.csv + meta.json).

The hardened labels come from one of:
  (a) The current meta.json if it has a 'hardened_label' field (unlikely)
  (b) A separate JSON file you provide via --hardened-labels-path
  (c) The null pilot's meta.json if you still have it

If no hardened labels are available, the script writes only the rule column
and the 2×2 collapses to a 1×2. You'll still get useful information
(MASSIF vs Δ on the same labels) but not the label-confound test.

USAGE
  python prepare_2x2_data.py \\
      --data-dir /path/to/massif_hidden_states \\
      --out-dir /path/to/2x2_input \\
      [--hardened-labels-path /path/to/hardened_labels.json] \\
      [--hardened-labels-format null_pilot]

The hardened labels file can be:
  - A JSON with the same structure as meta.json (records array with
    judge_label / hardened_label / hallucinated fields)
  - A CSV with idx,hardened columns
  - The null pilot's meta.json directly (--hardened-labels-format null_pilot)
"""

import os
import sys
import json
import argparse
import pandas as pd
from pathlib import Path


def parse_args():
    ap = argparse.ArgumentParser(description=__doc__,
                                  formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data-dir", required=True,
                    help="Directory containing per-model subdirs with traces.npz + meta.json")
    ap.add_argument("--out-dir", required=True,
                    help="Where to write features_<model>.csv and labels_<model>.csv")
    ap.add_argument("--models", nargs="+",
                    default=["qwen25-1.5b", "gemma2-2b-it", "llama32-1b-instruct"])
    ap.add_argument("--hardened-labels-path", default=None,
                    help="Path to hardened labels file (JSON or CSV). If None, only rule labels are written.")
    ap.add_argument("--hardened-labels-format", default="auto",
                    choices=["auto", "null_pilot", "csv", "json_records"],
                    help="Format of the hardened labels file.")
    ap.add_argument("--idx-field", default="id",
                    help="Field name in meta.json records for the prompt index (default: 'id')")
    return ap.parse_args()


def load_hardened_labels(path: str, format: str = "auto") -> dict:
    """
    Load hardened labels from a file. Returns a dict {idx: 0 or 1}.
    1 = hallucinated, 0 = correct. Items not in the dict are treated as excluded.

    Supported formats:
      - null_pilot: JSON with 'records' array, each record has 'id' and
        'judge_label' (TRUE/FALSE/UNVERIFIABLE) or 'hallucinated' (1/0)
      - json_records: same as null_pilot
      - csv: CSV with 'idx' and 'hardened' columns
      - auto: detect from file extension
    """
    if path is None:
        return {}

    if format == "auto":
        if path.endswith(".csv"):
            format = "csv"
        elif path.endswith(".json"):
            format = "null_pilot"
        else:
            raise ValueError(f"Cannot auto-detect format for {path}")

    if format == "csv":
        df = pd.read_csv(path)
        if "idx" not in df.columns or "hardened" not in df.columns:
            raise ValueError("CSV must have 'idx' and 'hardened' columns")
        return {int(r.idx): int(r.hardened) for r in df.itertuples()
                if pd.notna(r.hardened)}

    if format in ("null_pilot", "json_records"):
        with open(path) as f:
            data = json.load(f)
        # Handle both {records: [...]} and [...]
        records = data.get("records", data) if isinstance(data, dict) else data
        out = {}
        for r in records:
            idx = r.get("id", r.get("idx", r.get("question_id")))
            if idx is None:
                continue
            idx = int(idx)
            # Try different field names
            label = r.get("hardened_label")
            if label is None:
                label = r.get("hardened")
            if label is None:
                label = r.get("hallucinated")
            if label is None:
                label = r.get("judge_label")
            if label is None:
                continue
            # Normalize: TRUE/True/1/1.0 -> 0 (correct), FALSE/False/0/0.0 -> 1 (halluc)
            if isinstance(label, str):
                label_upper = label.strip().upper()
                if label_upper == "FALSE":
                    out[idx] = 1
                elif label_upper == "TRUE":
                    out[idx] = 0
                # UNVERIFIABLE or anything else -> excluded
            elif isinstance(label, (int, float)):
                if label in (0, 1):
                    out[idx] = int(label)
                elif label in (0.0, 1.0):
                    out[idx] = int(label)
        return out

    raise ValueError(f"Unknown format: {format}")


def extract_rule_labels(meta_path: Path) -> dict:
    """Extract rule-based labels from meta.json. Returns {idx: 0 or 1}."""
    with open(meta_path) as f:
        meta = json.load(f)
    records = meta.get("records", [])
    out = {}
    for r in records:
        idx = r.get("id", r.get("idx"))
        if idx is None:
            continue
        idx = int(idx)
        label = r.get("judge_label", "").strip().upper()
        if label == "FALSE":
            out[idx] = 1  # hallucinated
        elif label == "TRUE":
            out[idx] = 0  # correct
        # UNVERIFIABLE or anything else -> excluded
    return out


def extract_hardened_labels(meta_path: Path) -> dict:
    """Extract hardened (Groq) labels from meta.json. Returns {idx: 0 or 1}.

    The rejudge_with_groq.py script writes a 'hardened_label' field per record
    with values 'TRUE', 'FALSE', or 'UNVERIFIABLE'. This function reads those.
    """
    with open(meta_path) as f:
        meta = json.load(f)
    records = meta.get("records", [])
    out = {}
    for r in records:
        idx = r.get("id", r.get("idx"))
        if idx is None:
            continue
        idx = int(idx)
        label = r.get("hardened_label", "").strip().upper()
        if label == "FALSE":
            out[idx] = 1  # hallucinated
        elif label == "TRUE":
            out[idx] = 0  # correct
        # UNVERIFIABLE or anything else -> excluded
    return out


def prepare_features(features_path: Path, meta_path: Path, out_path: Path):
    """Read cached features.csv, add idx + n_tokens columns, write out."""
    df = pd.read_csv(features_path)

    # The features.csv has meta columns starting with _
    # _n_tokens, _n_layers, _d_model
    # We need:
    #   - idx column (0-based, matching the records in meta.json)
    #   - n_tokens column (from _n_tokens)
    #   - all feature columns (everything not starting with _)

    # Add idx
    df.insert(0, "idx", range(len(df)))

    # Rename _n_tokens to n_tokens (if present)
    if "_n_tokens" in df.columns:
        df = df.rename(columns={"_n_tokens": "n_tokens"})
    elif "n_tokens" not in df.columns:
        # Try to get n_tokens from meta.json
        with open(meta_path) as f:
            meta = json.load(f)
        records = meta.get("records", [])
        n_tokens = [r.get("n_tokens", 80) for r in records]
        df["n_tokens"] = n_tokens[:len(df)]

    # Drop other meta columns
    meta_cols = [c for c in df.columns if c.startswith("_")]
    df = df.drop(columns=meta_cols)

    df.to_csv(out_path, index=False)
    print(f"  features: {df.shape[1]} columns ({df.shape[1]-2} features + idx + n_tokens), "
          f"{df.shape[0]} rows -> {out_path}")
    return df


def prepare_labels(meta_path: Path, hardened_labels: dict, out_path: Path,
                    idx_field: str = "id"):
    """Write labels CSV with idx, hardened, rule columns.

    Hardened labels come from:
      1. External file (--hardened-labels-path), OR
      2. The 'hardened_label' field in meta.json (written by rejudge_with_groq.py)

    If neither is available, the hardened column is empty (1×2 instead of 2×2).
    """
    with open(meta_path) as f:
        meta = json.load(f)
    records = meta.get("records", [])

    # If no external hardened labels provided, try extracting from meta.json
    if not hardened_labels:
        hardened_labels = extract_hardened_labels(meta_path)
        if hardened_labels:
            print(f"  [info] extracted {len(hardened_labels)} hardened labels from meta.json")
            print(f"         (these were written by rejudge_with_groq.py)")

    rows = []
    for r in records:
        idx = r.get(idx_field, r.get("idx"))
        if idx is None:
            continue
        idx = int(idx)

        # Rule label
        rule_label = r.get("judge_label", "").strip().upper()
        rule = 1 if rule_label == "FALSE" else (0 if rule_label == "TRUE" else "")

        # Hardened label (from external file or from meta.json's hardened_label field)
        hardened = hardened_labels.get(idx, "")

        rows.append({"idx": idx, "hardened": hardened, "rule": rule})

    df = pd.DataFrame(rows)
    df.to_csv(out_path, index=False)

    n_h = df["hardened"].apply(lambda x: x == 1 or x == 0).sum()
    n_r = df["rule"].apply(lambda x: x == 1 or x == 0).sum()
    n_both = df.apply(lambda r: (r["hardened"] in (0, 1)) and (r["rule"] in (0, 1)), axis=1).sum()
    print(f"  labels: {len(df)} rows | hardened={n_h} rule={n_r} both={n_both} -> {out_path}")
    if n_h == 0:
        print(f"  [warn] no hardened labels — 2×2 collapses to 1×2 (MASSIF vs Δ on rule labels only)")
        print(f"         to get hardened labels, run: python rejudge_with_groq.py --data-dir ...")
    return df


def main():
    args = parse_args()
    data_dir = Path(args.data_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Load hardened labels (if provided)
    hardened_labels = {}
    if args.hardened_labels_path:
        print(f"Loading hardened labels from {args.hardened_labels_path} "
              f"(format: {args.hardened_labels_format})")
        hardened_labels = load_hardened_labels(args.hardened_labels_path,
                                                args.hardened_labels_format)
        print(f"  loaded {len(hardened_labels)} hardened labels")
    else:
        print("WARNING: no --hardened-labels-path provided.")
        print("         The labels CSV will have empty 'hardened' column.")
        print("         The 2x2 will collapse to a 1x2 (only rule labels).")

    for model in args.models:
        model_dir = data_dir / model
        if not model_dir.exists():
            print(f"\n[skip] {model}: not found at {model_dir}")
            continue

        features_path = model_dir / "analysis_a" / "features.csv"
        meta_path = model_dir / "meta.json"

        if not features_path.exists():
            print(f"\n[skip] {model}: features.csv not found at {features_path}")
            print(f"  Run analysis_a_massif.py first to generate cached features.")
            continue
        if not meta_path.exists():
            print(f"\n[skip] {model}: meta.json not found at {meta_path}")
            continue

        print(f"\n{'='*60}")
        print(f"Preparing {model}")
        print(f"{'='*60}")

        # Map model slug to the filename the 2x2 script expects
        # The 2x2 script's --models arg should match the filename stem
        # e.g. --models Qwen2.5-1.5B expects features_Qwen2.5-1.5B.csv
        # We'll write both the slug and a "nice name" version
        model_filename = model  # use the slug as-is

        out_features = out_dir / f"features_{model_filename}.csv"
        out_labels = out_dir / f"labels_{model_filename}.csv"

        prepare_features(features_path, meta_path, out_features)
        prepare_labels(meta_path, hardened_labels, out_labels, args.idx_field)

    print(f"\n{'='*60}")
    print(f"Done. Files in {out_dir}/")
    print(f"{'='*60}")
    print()
    print("Now run the 2x2 permutation test:")
    print(f"  python two_by_two_permutation.py \\")
    print(f"    --features-dir {out_dir} \\")
    print(f"    --labels-dir {out_dir} \\")
    print(f"    --models {' '.join(args.models)} \\")
    print(f"    --perms 10000 \\")
    print(f"    --lasso --lasso-perms 200 \\")
    print(f"    --out {out_dir}/results_2x2")
    print()
    print("Or first run the demo to verify the script works:")
    print(f"  python two_by_two_permutation.py --demo")


if __name__ == "__main__":
    main()
