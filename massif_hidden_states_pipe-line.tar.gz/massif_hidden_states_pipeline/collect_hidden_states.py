"""
collect_hidden_states.py
========================

Unified collection script for the MASSIF x Friction Delta follow-up study.

Re-runs the TruthfulQA pilot on the same 3 models used in the null pilot
(Qwen2.5-1.5B, Gemma-2B-IT, Llama-3.2-1B-Instruct) but with the hidden-state
hook changed from `output[0].var()` to `output[0].detach()` so we capture the
FULL hidden-state vector at every layer, every generated token.

Output format (per model):
    /content/drive/MyDrive/massif_hidden_states/<model_slug>/
        traces.npz           # hidden states, shape [n_prompts, n_tokens, n_layers, d_model] (bf16)
        meta.json            # prompts, generated text, judge labels (filled later), layer names, tokenization
        generation_log.txt    # human-readable log

Storage estimate per model (worst case 50 prompts x 80 tokens x 28 layers x 1536 dim x 2 bytes):
    ~340 MB per model, ~1 GB total. Fits comfortably on Drive.

Designed to run on Google Colab (free T4) or any single-GPU machine with ~16GB VRAM.
"""

import os
import sys
import json
import gc
import time
import warnings
from datetime import datetime
from pathlib import Path

warnings.filterwarnings("ignore")

# ------------------------------------------------------------------
# Environment detection
# ------------------------------------------------------------------

def detect_environment():
    """Return ('colab', drive_path) or ('local', None)."""
    if "google.colab" in sys.modules:
        try:
            from google.colab import drive  # noqa: F401
            return "colab", "/content/drive/MyDrive"
        except Exception:
            return "colab", "/content"
    return "local", None


ENV, DRIVE_ROOT = detect_environment()
print(f"[env] {ENV}, drive_root={DRIVE_ROOT}")

# ------------------------------------------------------------------
# Install deps if needed (Colab only)
# ------------------------------------------------------------------

if ENV == "colab":
    import subprocess
    for pkg in ["transformers", "torch", "datasets", "accelerate", "huggingface_hub"]:
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", pkg],
                       check=False, capture_output=True)

import torch
import numpy as np
from transformers import AutoTokenizer, AutoModelForCausalLM

# Print version on startup so you always know which version is running
try:
    from VERSION import print_version, get_version
    print_version()
    _PIPELINE_VERSION = get_version()
except ImportError:
    _PIPELINE_VERSION = "unknown (VERSION.py not found)"

# ------------------------------------------------------------------
# HF auth
# ------------------------------------------------------------------

HF_TOKEN = None
if ENV == "colab":
    try:
        from google.colab import userdata
        HF_TOKEN = userdata.get("colab-read")
        if not HF_TOKEN:
            HF_TOKEN = userdata.get("HF_TOKEN")
    except Exception:
        HF_TOKEN = os.environ.get("HF_TOKEN", None)
else:
    HF_TOKEN = os.environ.get("HF_TOKEN", None)

# Fallback: try huggingface_hub's cached token if env var is empty/invalid
if not HF_TOKEN:
    try:
        from huggingface_hub import HfFolder
        HF_TOKEN = HfFolder.get_token()
    except Exception:
        pass

# Verify the token actually works (whoami). If not, print a clear error.
def _verify_hf_token(token):
    if not token:
        return False, "no token"
    try:
        from huggingface_hub import HfApi
        api = HfApi(token=token)
        info = api.whoami()
        if info and info.get("name"):
            return True, info["name"]
        return False, "whoami returned no name"
    except Exception as e:
        return False, str(e)[:120]

_ok, _msg = _verify_hf_token(HF_TOKEN)
if _ok:
    print(f"[hf] token valid (user: {_msg})")
else:
    print(f"[hf] token invalid or missing: {_msg}")
    print(f"[hf] To fix:")
    print(f"[hf]   1) In a NEW cell BEFORE importing transformers: import os; os.environ['HF_TOKEN'] = 'hf_xxx'")
    print(f"[hf]   2) OR run: from huggingface_hub import login; login(token='hf_xxx')")
    print(f"[hf]   3) Then RESTART the kernel and re-run")

# ------------------------------------------------------------------
# Configuration
# ------------------------------------------------------------------

MODELS = {
    "qwen25-1.5b": {
        "hf_id": "Qwen/Qwen2.5-1.5B",
        "layer_module_attr": "model.layers",
        "n_layers_expected": 28,
        "d_model": 1536,
        "chat_template": True,
    },
    "gemma2-2b-it": {
        "hf_id": "google/gemma-2-2b-it",
        "layer_module_attr": "model.layers",
        "n_layers_expected": 26,
        "d_model": 2304,
        "chat_template": True,
    },
    "llama32-1b-instruct": {
        "hf_id": "meta-llama/Llama-3.2-1B-Instruct",
        "layer_module_attr": "model.layers",
        "n_layers_expected": 16,
        "d_model": 2048,
        "chat_template": True,
    },
}

N_PROMPTS = 50
MAX_NEW_TOKENS = 80
BATCH_SIZE = 1
SAVE_DIR = Path(DRIVE_ROOT or "./") / "massif_hidden_states"
SAVE_DIR.mkdir(parents=True, exist_ok=True)
print(f"[disk] save dir: {SAVE_DIR}")

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
DTYPE = torch.bfloat16 if DEVICE == "cuda" else torch.float32
print(f"[hw] device={DEVICE}, dtype={DTYPE}")


# ------------------------------------------------------------------
# Hidden-state hook
# ------------------------------------------------------------------

class HiddenStateCollector:
    """
    Registers forward hooks on every transformer block, plus (optionally)
    forward pre-hooks on every layer's self_attn.o_proj to capture per-head
    attention outputs.

    Per-block hook (always on):
        Captures `output[0].detach()` — the full hidden-state tensor at that
        layer's output, sliced to the last token position.
        Shape: [batch=1, d_model]

    Per-head hook (when capture_heads=True):
        Captures the INPUT to self_attn.o_proj, which is the concatenation
        of all attention heads BEFORE the W_O projection mixes them.
        Shape: [batch=1, n_heads * head_dim]  → reshaped to [n_heads, head_dim]
        This is required for the canonical H*L Kuramoto R_t (Metric 8.1).

    Storage layout during generation:
        self.buffer[layer_idx]      = list of [1, d_model] tensors
        self.head_buffer[layer_idx] = list of [1, n_heads, head_dim] tensors

    After generation:
        self.stack()         -> [n_steps, n_layers, d_model]
        self.stack_heads()   -> [n_steps, n_layers, n_heads, head_dim]
    """

    def __init__(self, layers_module, capture_heads=False, o_proj_attr="self_attn.o_proj"):
        self.layers = list(layers_module)
        self.handles = []
        self.buffer = [[] for _ in self.layers]
        self.head_buffer = [[] for _ in self.layers] if capture_heads else None
        self.capture_heads = capture_heads
        self.o_proj_attr = o_proj_attr
        self.active = False

    def _make_hook(self, layer_idx):
        def hook(module, inputs, output):
            if not self.active:
                return
            if isinstance(output, tuple):
                hidden = output[0]
            else:
                hidden = output
            # shape: [batch, seq_len, d_model] -> keep last token only
            last_token_hidden = hidden[:, -1, :].detach().to("cpu", copy=True)
            self.buffer[layer_idx].append(last_token_hidden)
        return hook

    def _make_head_hook(self, layer_idx):
        """Pre-hook on o_proj: captures input (concatenated heads)."""
        def hook(module, inputs):
            if not self.active:
                return
            # inputs is a tuple; first element is the input tensor
            x = inputs[0]  # [batch, seq_len, n_heads * head_dim]
            # slice to last token
            last = x[:, -1, :].detach().to("cpu", copy=True)  # [1, n_heads * head_dim]
            self.head_buffer[layer_idx].append(last)
        return hook

    def register(self):
        for i, layer in enumerate(self.layers):
            h = layer.register_forward_hook(self._make_hook(i))
            self.handles.append(h)
            if self.capture_heads:
                # Find o_proj module
                o_proj = layer
                for attr in self.o_proj_attr.split("."):
                    o_proj = getattr(o_proj, attr, None)
                    if o_proj is None:
                        break
                if o_proj is not None:
                    hh = o_proj.register_forward_pre_hook(self._make_head_hook(i))
                    self.handles.append(hh)
                else:
                    print(f"[warn] could not find {self.o_proj_attr} on layer {i}; "
                          "head capture disabled for this layer")

    def clear(self):
        self.buffer = [[] for _ in self.layers]
        if self.head_buffer is not None:
            self.head_buffer = [[] for _ in self.layers]

    def remove(self):
        for h in self.handles:
            h.remove()
        self.handles = []

    def start(self):
        self.active = True
        self.clear()

    def stop(self):
        self.active = False

    def stack(self):
        """Returns tensor of shape [n_steps, n_layers, d_model]."""
        n_steps = len(self.buffer[0])
        if n_steps == 0:
            return None
        per_layer = [
            torch.stack(self.buffer[i], dim=0).squeeze(1)  # [n_steps, d_model]
            for i in range(len(self.layers))
        ]
        return torch.stack(per_layer, dim=1)  # [n_steps, n_layers, d_model]

    def stack_heads(self, n_heads, head_dim):
        """
        Returns tensor of shape [n_steps, n_layers, n_heads, head_dim].
        Requires capture_heads=True at construction.
        """
        if self.head_buffer is None:
            return None
        n_steps = len(self.head_buffer[0]) if self.head_buffer else 0
        if n_steps == 0:
            return None
        per_layer = []
        for i in range(len(self.layers)):
            # each entry is [1, n_heads * head_dim]
            stacked = torch.stack(self.head_buffer[i], dim=0).squeeze(1)  # [n_steps, n_heads*head_dim]
            stacked = stacked.view(n_steps, n_heads, head_dim)
            per_layer.append(stacked)
        return torch.stack(per_layer, dim=1)  # [n_steps, n_layers, n_heads, head_dim]


# ------------------------------------------------------------------
# Data loading
# ------------------------------------------------------------------

def load_truthfulqa(n_prompts=N_PROMPTS):
    from datasets import load_dataset
    ds = load_dataset("truthfulqa/truthful_qa", "generation", split="validation")
    out = []
    for i, row in enumerate(ds):
        if i >= n_prompts:
            break
        out.append({
            "id": i,
            "question": row["question"],
            "best_answer": row["best_answer"],
            "correct_answers": list(row["correct_answers"]),
            "incorrect_answers": list(row["incorrect_answers"]),
        })
    return out


# ------------------------------------------------------------------
# Model loading
# ------------------------------------------------------------------

def load_model(model_cfg, slug):
    print(f"\n[model] loading {slug} ({model_cfg['hf_id']})")
    tok = AutoTokenizer.from_pretrained(model_cfg["hf_id"], token=HF_TOKEN)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        model_cfg["hf_id"],
        dtype=DTYPE,                 # `torch_dtype` is deprecated in newer transformers
        device_map=DEVICE,
        token=HF_TOKEN,
        low_cpu_mem_usage=True,
    )
    model.eval()

    layer_mod = model
    for attr in model_cfg["layer_module_attr"].split("."):
        layer_mod = getattr(layer_mod, attr)
    n_layers_actual = len(list(layer_mod))
    if n_layers_actual != model_cfg["n_layers_expected"]:
        print(f"[warn] {slug}: expected {model_cfg['n_layers_expected']} layers, found {n_layers_actual}")
        model_cfg["n_layers_expected"] = n_layers_actual

    # Read attention head config from model config (handles GQA / MQA correctly)
    cfg = model.config
    n_heads = getattr(cfg, "num_attention_heads", None)
    head_dim = getattr(cfg, "head_dim", None)
    if head_dim is None and n_heads is not None:
        head_dim = cfg.hidden_size // n_heads
    n_kv_heads = getattr(cfg, "num_key_value_heads", n_heads)
    model_cfg["n_heads"] = n_heads
    model_cfg["head_dim"] = head_dim
    model_cfg["n_kv_heads"] = n_kv_heads
    print(f"[model] {slug}: {n_layers_actual} layers, d_model={model_cfg['d_model']}, "
          f"n_heads={n_heads}, head_dim={head_dim}, n_kv_heads={n_kv_heads}")
    return tok, model, layer_mod


# ------------------------------------------------------------------
# Generation
# ------------------------------------------------------------------

def build_prompt(tokenizer, question, model_cfg):
    if model_cfg.get("chat_template"):
        msgs = [{"role": "user", "content": question}]
        try:
            text = tokenizer.apply_chat_template(
                msgs, tokenize=False, add_generation_prompt=True
            )
        except Exception:
            text = f"Question: {question}\nAnswer:"
    else:
        text = f"Question: {question}\nAnswer:"
    return text


@torch.no_grad()
def generate_with_hooks(model, tokenizer, prompt_text, collector,
                         max_new_tokens=MAX_NEW_TOKENS,
                         n_heads=None, head_dim=None,
                         temperature=0.0, seed=None):
    """
    Generation with hidden-state + per-head capture at every step.

    Args:
        temperature: 0.0 for greedy (default), >0 for stochastic sampling.
        seed: optional torch seed for reproducibility (only used if temp>0).

    Returns:
        generated_text: str
        hidden_states: tensor [n_steps, n_layers, d_model]  (bf16 on CPU)
        head_states:   tensor [n_steps, n_layers, n_heads, head_dim] or None
        token_ids: list[int]
    """
    inputs = tokenizer(prompt_text, return_tensors="pt").to(DEVICE)
    input_ids = inputs["input_ids"]
    prompt_len = input_ids.shape[1]

    if seed is not None:
        torch.manual_seed(seed)

    collector.start()
    try:
        gen_kwargs = dict(
            max_new_tokens=max_new_tokens,
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id,
            use_cache=True,
        )
        if temperature > 0:
            gen_kwargs.update(do_sample=True, temperature=temperature, top_p=0.95)
        else:
            gen_kwargs.update(do_sample=False, temperature=1.0, top_p=1.0)
        out_ids = model.generate(input_ids, **gen_kwargs)
    finally:
        collector.stop()

    new_token_ids = out_ids[0, prompt_len:].tolist()
    n_new = len(new_token_ids)
    if n_new == 0:
        return "", None, None, []

    raw = collector.stack()
    if raw is None:
        return "", None, None, []

    n_calls = raw.shape[0]
    if n_calls > n_new:
        raw = raw[-n_new:]
    elif n_calls < n_new:
        n_new = n_calls

    # Per-head states
    head_states = None
    if collector.head_buffer is not None and n_heads is not None and head_dim is not None:
        head_states = collector.stack_heads(n_heads, head_dim)
        if head_states is not None:
            n_calls_h = head_states.shape[0]
            if n_calls_h > n_new:
                head_states = head_states[-n_new:]
            elif n_calls_h < n_new:
                pass  # leave as-is

    gen_text = tokenizer.decode(new_token_ids, skip_special_tokens=True)
    return gen_text, raw, head_states, new_token_ids


# ------------------------------------------------------------------
# Per-model collection
# ------------------------------------------------------------------

def collect_for_model(slug, model_cfg, prompts, multi_run_n=1, multi_run_temp=0.7):
    """
    Collect hidden states + per-head outputs for one model.

    multi_run_n: number of stochastic runs per prompt (in addition to 1 greedy).
                 1 = single greedy run only (default). Use 5+ for canonical
                 multi-run Kuramoto R_t (Metric 8.1, ensemble = N runs).
    multi_run_temp: temperature for stochastic runs (default 0.7).
    """
    out_dir = SAVE_DIR / slug
    out_dir.mkdir(parents=True, exist_ok=True)

    traces_path = out_dir / "traces.npz"
    meta_path = out_dir / "meta.json"
    if traces_path.exists() and meta_path.exists():
        print(f"[skip] {slug} already collected ({traces_path})")
        return

    tok, model, layer_mod = load_model(model_cfg, slug)
    n_heads = model_cfg.get("n_heads")
    head_dim = model_cfg.get("head_dim")
    capture_heads = n_heads is not None and head_dim is not None
    collector = HiddenStateCollector(layer_mod, capture_heads=capture_heads)
    collector.register()

    all_hidden = []        # list of [n_tok, n_layers, d_model]  (greedy run, used for judging)
    all_heads = []         # list of [n_tok, n_layers, n_heads, head_dim]  (greedy run)
    all_multirun_hidden = []  # list of lists: [prompt_i][run_r] -> [n_tok, n_layers, d_model]
    meta_records = []
    layer_names = [f"layer_{i}" for i in range(len(list(layer_mod)))]

    log_path = out_dir / "generation_log.txt"
    log_f = open(log_path, "w", buffering=1)

    t_start = time.time()
    for idx, item in enumerate(prompts):
        q = item["question"]
        prompt_text = build_prompt(tok, q, model_cfg)

        # --- Greedy run (always) ---
        try:
            gen_text, hidden, heads, token_ids = generate_with_hooks(
                model, tok, prompt_text, collector,
                n_heads=n_heads, head_dim=head_dim,
                temperature=0.0
            )
        except Exception as e:
            print(f"[err] {slug} prompt {idx} greedy: {e}", file=log_f)
            continue

        if hidden is None or hidden.shape[0] == 0:
            print(f"[skip] {slug} prompt {idx}: empty hidden states", file=log_f)
            continue

        # Convert to float32 for numpy storage (numpy doesn't support bfloat16).
        # Storage cost: ~2x larger than bf16, but bf16 precision is preserved
        # by the float32 representation (no information loss).
        hidden_np = hidden.to(torch.float32).numpy()
        all_hidden.append(hidden_np)
        heads_np = heads.to(torch.float32).numpy() if heads is not None else None
        all_heads.append(heads_np)

        # --- Multi-run stochastic runs (optional) ---
        multirun_runs = []
        if multi_run_n > 1:
            for r in range(multi_run_n - 1):
                try:
                    _, h_r, _, _ = generate_with_hooks(
                        model, tok, prompt_text, collector,
                        n_heads=n_heads, head_dim=head_dim,
                        temperature=multi_run_temp, seed=42 + r * 1000 + idx
                    )
                    if h_r is not None and h_r.shape[0] > 0:
                        # float32 (numpy doesn't support bfloat16)
                        multirun_runs.append(h_r.to(torch.float32).numpy())
                except Exception as e:
                    print(f"[warn] {slug} prompt {idx} run {r}: {e}", file=log_f)
                    continue

        all_multirun_hidden.append(multirun_runs if multirun_runs else None)

        meta_records.append({
            "id": item["id"],
            "question": q,
            "best_answer": item["best_answer"],
            "correct_answers": item["correct_answers"],
            "incorrect_answers": item["incorrect_answers"],
            "generated_text": gen_text,
            "token_ids": token_ids,
            "n_tokens": len(token_ids),
            "n_layers": int(hidden.shape[1]),
            "d_model": int(hidden.shape[2]),
            "n_heads": int(n_heads) if n_heads else None,
            "head_dim": int(head_dim) if head_dim else None,
            "multirun_n_runs": len(multirun_runs) + 1,  # incl greedy
            "multirun_temp": multi_run_temp if multi_run_n > 1 else None,
        })

        elapsed = time.time() - t_start
        rate = (idx + 1) / elapsed
        eta = (len(prompts) - idx - 1) / rate if rate > 0 else 0
        log_line = f"[{slug}] {idx+1}/{len(prompts)} n_tok={len(token_ids)} "
        if multi_run_n > 1:
            log_line += f"mr_runs={len(multirun_runs)+1} "
        log_line += f"elapsed={elapsed:.0f}s rate={rate:.2f}/s eta={eta:.0f}s"
        print(log_line, file=log_f)
        print(log_line)
        log_f.flush()

        if (idx + 1) % 10 == 0:
            _save_incremental(all_hidden, all_heads, all_multirun_hidden,
                              meta_records, layer_names, out_dir)

    log_f.close()

    # Final save
    save_kwargs = dict(
        hidden_states=np.array(all_hidden, dtype=object),
        layer_names=np.array(layer_names),
    )
    if all_heads and all_heads[0] is not None:
        save_kwargs["head_states"] = np.array(all_heads, dtype=object)
    if multi_run_n > 1 and any(mr is not None for mr in all_multirun_hidden):
        # store multi-run as object array (variable N due to occasional failures)
        save_kwargs["multirun_hidden_states"] = np.array(all_multirun_hidden, dtype=object)
    np.savez_compressed(traces_path, **save_kwargs)

    with open(meta_path, "w") as f:
        json.dump({
            "model_slug": slug,
            "hf_id": model_cfg["hf_id"],
            "n_prompts": len(meta_records),
            "layer_names": layer_names,
            "n_layers": len(layer_names),
            "d_model": model_cfg["d_model"],
            "n_heads": int(n_heads) if n_heads else None,
            "head_dim": int(head_dim) if head_dim else None,
            "n_kv_heads": int(model_cfg.get("n_kv_heads", n_heads)) if n_heads else None,
            "max_new_tokens": MAX_NEW_TOKENS,
            "multi_run_n": multi_run_n,
            "multi_run_temp": multi_run_temp,
            "captured_heads": capture_heads,
            "collected_at": datetime.now().isoformat(),
            "pipeline_version": _PIPELINE_VERSION,
            "records": meta_records,
        }, f, indent=2)

    print(f"[done] {slug}: {len(meta_records)} prompts -> {traces_path}")
    print(f"[size] {traces_path.stat().st_size / 1e6:.1f} MB")

    collector.remove()
    del model, tok
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()


def _save_incremental(all_hidden, all_heads, all_multirun_hidden,
                      meta_records, layer_names, out_dir):
    inc_path = out_dir / "traces_incremental.npz"
    inc_meta_path = out_dir / "meta_incremental.json"
    save_kwargs = dict(
        hidden_states=np.array(all_hidden, dtype=object),
        layer_names=np.array(layer_names),
    )
    if all_heads and all_heads[0] is not None:
        save_kwargs["head_states"] = np.array(all_heads, dtype=object)
    if any(mr is not None for mr in all_multirun_hidden):
        save_kwargs["multirun_hidden_states"] = np.array(all_multirun_hidden, dtype=object)
    np.savez_compressed(inc_path, **save_kwargs)
    with open(inc_meta_path, "w") as f:
        json.dump({"records": meta_records, "layer_names": layer_names}, f)


# ------------------------------------------------------------------
# Main
# ------------------------------------------------------------------

def main(multi_run=None, multi_run_temp=None, models=None,
         n_prompts=None, max_new_tokens=None, save_dir=None,
         **kwargs):
    """
    Entry point. Works BOTH as a CLI script AND as a direct call from a
    Jupyter/Colab notebook cell.

    Usage from CLI:
        python collect_hidden_states.py --multi-run 5
        python collect_hidden_states.py --models qwen25-1.5b llama32-1b-instruct

    Usage from a notebook cell:
        # default: 1 greedy run + per-head capture (canonical H*L Kuramoto R_t)
        main()

        # canonical multi-run ensemble
        main(multi_run=5)

        # only one model, faster iteration
        main(models=['qwen25-1.5b'])

        # multi-run + specific models
        main(multi_run=5, models=['qwen25-1.5b', 'gemma2-2b-it'])

    If you pass kwargs directly, they win. If you don't, and you're in a
    notebook, defaults are used. If you're on CLI, argparse runs.
    """
    # Detect environment
    in_notebook = ("ipykernel" in sys.modules
                    or "google.colab" in sys.modules
                    or "IPython" in sys.modules)

    if in_notebook and multi_run is None and models is None:
        # Notebook without explicit kwargs -> use notebook defaults
        multi_run = 1
        multi_run_temp = 0.7
        models = list(MODELS.keys())
    elif in_notebook:
        # Notebook with explicit kwargs -> fill in defaults for the rest
        if multi_run is None:
            multi_run = 1
        if multi_run_temp is None:
            multi_run_temp = 0.7
        if models is None:
            models = list(MODELS.keys())
    else:
        # CLI: use argparse
        import argparse
        ap = argparse.ArgumentParser()
        ap.add_argument("--multi-run", type=int, default=1,
                        help="Number of runs per prompt. 1 (default) = greedy only. "
                             "Use 5+ for canonical multi-run Kuramoto R_t (Metric 8.1).")
        ap.add_argument("--multi-run-temp", type=float, default=0.7,
                        help="Temperature for stochastic multi-runs (default 0.7).")
        ap.add_argument("--models", nargs="+", default=list(MODELS.keys()))
        cli_args = ap.parse_args()
        if multi_run is None:
            multi_run = cli_args.multi_run
        if multi_run_temp is None:
            multi_run_temp = cli_args.multi_run_temp
        if models is None:
            models = cli_args.models

    # Apply optional overrides (work in both modes)
    global N_PROMPTS, MAX_NEW_TOKENS, SAVE_DIR
    if n_prompts is not None:
        N_PROMPTS = n_prompts
    if max_new_tokens is not None:
        MAX_NEW_TOKENS = max_new_tokens
    if save_dir is not None:
        SAVE_DIR = Path(save_dir)
        SAVE_DIR.mkdir(parents=True, exist_ok=True)

    print("=" * 70)
    print("MASSIF Hidden-State Collection")
    print("=" * 70)
    print(f"Save dir: {SAVE_DIR}")
    print(f"Models: {models}")
    print(f"N prompts: {N_PROMPTS}")
    print(f"Max new tokens: {MAX_NEW_TOKENS}")
    print(f"Multi-run N: {multi_run} (temp={multi_run_temp})")
    print(f"Per-head capture: enabled (canonical H*L Kuramoto R_t available)")
    if multi_run > 1:
        est_storage_gb = (multi_run * N_PROMPTS * MAX_NEW_TOKENS
                          * 28 * 1536 * 2) / 1e9 * len(models)
        print(f"  Estimated total storage: ~{est_storage_gb:.1f} GB")
    print()

    prompts = load_truthfulqa()
    print(f"[data] loaded {len(prompts)} TruthfulQA prompts")

    for slug in models:
        if slug not in MODELS:
            print(f"[skip] unknown model slug: {slug}")
            continue
        try:
            collect_for_model(slug, MODELS[slug], prompts,
                              multi_run_n=multi_run,
                              multi_run_temp=multi_run_temp)
        except Exception as e:
            print(f"[fail] {slug}: {e}")
            import traceback
            traceback.print_exc()
            continue

    print("\n[all done] output in:", SAVE_DIR)


if __name__ == "__main__":
    main()
