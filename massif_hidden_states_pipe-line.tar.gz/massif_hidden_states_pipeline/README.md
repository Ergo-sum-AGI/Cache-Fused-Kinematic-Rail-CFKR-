# MASSIF Hidden-State Study — Runbook

Follow-up to the null Friction Delta pilot. Tests whether the MASSIF feature
family (R_t, V_t, kappa_t, eigenvalue spectrum — validated for recursive
collapse across 12 architectures in Zenodo 20542872 / 20575616) recovers
hallucination signal that variance-only Friction Delta missed.

## Files

| Script | Purpose |
|---|---|
| `collect_hidden_states.py` | Run on Colab/T4. Captures full hidden-state vectors at every layer of every generated token for the 3 pilot models on TruthfulQA. |
| `massif_features.py` | Feature library. Computes I_t, σ_t, Φ_t, Ψ_t, κ_t (original MASSIF) + R_t (Kuramoto, 2 flavors), V_t/A_t derivatives, eigenvalue spectrum, τ_collapse horizon, plus variance-only Friction Delta for direct comparison. |
| `analysis_a_massif.py` | Analysis A. Per-feature AUROC + BH-FDR + LASSO-CV + 1000-shuffle permutation null. |
| `analysis_b_dynamical_classes.py` | Analysis B. Per-prompt dynamical-class assignment (Accelerator/Decelerator/Neutral/Instant/Stochastic). Tests whether hallucinations cluster by class. |
| `make_synthetic_traces.py` | Smoke test. Generates synthetic data with known injected signal to validate the pipeline. |

## How to run

### Step 1 — Collect (Colab, ~30-45 min single-run, ~2-3h for multi-run)

Two collection modes:

**Default (single greedy run + per-head capture):**
- 1 greedy generation per prompt (for judging)
- Captures per-block hidden states + per-attention-head outputs
- Enables canonical H·L Kuramoto R_t (single-run surrogate per Metric 8.1)
- ~30-45 min for all 3 models on T4

```bash
python collect_hidden_states.py
```

**Multi-run (canonical ensemble):**
- 1 greedy + (N-1) stochastic runs at T=0.7 per prompt
- Captures per-block hidden states + per-attention-head outputs
- Enables canonical N-run Kuramoto R_t (true ensemble per Metric 8.1)
- ~2-3 hours for all 3 models with N=5 on T4

```bash
python collect_hidden_states.py --multi-run 5
```

Output: `/content/drive/MyDrive/massif_hidden_states/<model_slug>/{traces.npz, meta.json, generation_log.txt}`.
Storage: ~1 GB single-run, ~5 GB with multi-run N=5.

### Step 2 — Judge labels (optional, ~5 min)

If `meta.json` doesn't have `judge_label` per record, set `GROQ_API_KEY` env
var and re-run Analysis A with `--re-judge`. Uses GPT-OSS-120b with the
same prompt template as the null pilot for direct comparability.

### Step 3 — Analysis A (CPU, ~10 min per model)

```bash
python analysis_a_massif.py \
    --data-dir /content/drive/MyDrive/massif_hidden_states \
    --models qwen25-1.5b gemma2-2b-it llama32-1b-instruct \
    --n-permutations 1000
```

Output per model:
- `features.csv` — [n_prompts, ~200 features]
- `per_feature_auroc.csv` — every feature's AUROC + BH-FDR verdict
- `permutation_null.json` — null distribution of LASSO-CV AUROC
- `summary.json` — one-row summary
- `figures/permutation_null.png` — null distribution plot

### Step 4 — Analysis B (CPU, ~2 min per model)

```bash
python analysis_b_dynamical_classes.py \
    --data-dir /content/drive/MyDrive/massif_hidden_states \
    --models qwen25-1.5b gemma2-2b-it llama32-1b-instruct
```

Output per model:
- `per_prompt_classes.csv` — class assignment per prompt + all R_t trajectory stats
- `class_summary.csv` — class × hallucination contingency table
- `statistical_tests.json` — Fisher's exact, per-class AUROC, V_slope AUROC, LASSO on dyn-class features
- `figures/` — R_within trajectory plots by class, hallucination rate by class

## Expected outcomes

| Outcome | Interpretation |
|---|---|
| LASSO-CV AUROC > null 95th pctile (~0.75) on at least one model | MASSIF features recover signal that variance-only missed → publishable positive result |
| Top feature is in {R_cross, R_within, V_cross, eig_lambda1, eig_participation_ratio} | Confirms the covariance-structure hypothesis from the INSIDE framework |
| Analysis B shows hallucinations cluster in Instant/Stochastic classes | Cross-product finding: hallucination shares dynamical pathology with recursive collapse |
| All nulls again | Still informative — bounds effect size and constrains future directions (full-trajectory SDE drift, multi-run ensembles) |

## Synthetic smoke test (run before Colab)

```bash
python make_synthetic_traces.py
python analysis_a_massif.py --data-dir /tmp/massif_synthetic --models synth_a synth_b synth_c --n-permutations 100
python analysis_b_dynamical_classes.py --data-dir /tmp/massif_synthetic --models synth_a synth_b synth_c
```

Expected: AUROC = 1.0 on all 3 synthetic models. Top features should now be the canonical R_t variants (R_canonical_multirun_max/mean, R_canonical_heads_max) since the synthetic data has synchronization signal injected.

## Differences from the null pilot

| Pilot (null) | This study |
|---|---|
| `output[0].var()` (variance only) | `output[0].detach()` (full hidden vector) + per-head outputs |
| 49 features (7 splits × 7 aggregations) | ~240 features (MASSIF + eigenvalue spectrum + canonical R_t) |
| Per-feature permutation test | Per-feature + LASSO-CV + max-stat permutation |
| No dynamical-class taxonomy | Per-prompt Accelerator/Decelerator/Neutral/Instant assignment |
| Variance-only = covariance diagonal | Full covariance via eigenvalue decomposition (INSIDE framework) |
| No Kuramoto order parameter | Canonical R_t^Kuramoto per Metric 8.1 (both multi-run and H*L ensembles, velocity-corrected) |

## Canonical R_t (Metric 8.1) implementation

The Kuramoto Latent Synchronization Order Parameter is implemented exactly per the canonical definition:

```
R_t^Kuramoto = || (1/N) sum_{r=1}^N u_t^(r) ||_2
where u_t^(r) = v_t^(r) / ||v_t^(r)||_2  (unit VELOCITY)
      v_t^(r) = h_t^(r) - h_{t-1}^(r)   (velocity = hidden state difference)
```

Two valid ensembles (per the canonical spec):
- **(A) Multi-run** (`R_t_kuramoto_multi_run`): N independent stochastic runs of the same prompt. Requires `--multi-run N` at collection time. This is the canonical ensemble.
- **(B) H·L attention heads** (`R_t_kuramoto_heads`): Single-run, uses per-attention-head outputs (captured via o_proj pre-hook) as the ensemble. Mentioned as the single-run surrogate in the canonical spec.

Two non-canonical surrogates are also computed for ablation:
- `R_t_cross_layer_velocity`: ensemble = layers, vector = unit velocity
- `R_within_trajectory_velocity`: ensemble = past k tokens, vector = unit velocity

These are clearly labeled in feature names:
- `R_canonical_multirun_*` — canonical (A)
- `R_canonical_heads_*` — canonical surrogate (B)
- `R_cross_*`, `R_within_*` — non-canonical surrogates (kept for ablation)

If the canonical R_t doesn't recover signal but the surrogates do, that's an important methodological finding. If the canonical R_t recovers signal where the surrogates didn't, that confirms the metric was the right tool all along.

## Full canonical glossary alignment (v5.0)

All metrics in this pipeline follow the **MyceliaLM & MASSIF Master Telemetry Glossary v5.0** (Solis, October 2026). The glossary is included as `MASTER_GLOSSARY_v5.tex`. Each canonical metric is labeled with its glossary Metric ID in the source code and prefixed `canonical_` in the feature names.

### Canonical metrics implemented

| Section | Metric ID | Name | Feature prefix |
|---|---|---|---|
| 2.1 | SDE Drift | D^(1) | `canonical_D1_norm` |
| 2.2 | Diffusion | D^(2)_tr, D^(2)_dir | `canonical_D2_tr`, `canonical_D2_dir` |
| 2.3 | 4th Kramers-Moyal | D^(4) | `canonical_D4` |
| 2.4 | Pawula Ratio | R_Pawula | `canonical_pawula_ratio` |
| 2.5 | SDE SNR | ρ_dir | `canonical_sde_snr`, `canonical_sde_regime` |
| 3.1 | Latent Velocity | v^(l)_t (layer direction) | `canonical_v_layer_*` |
| 3.2 | Latent Acceleration | a^(l)_t | `canonical_a_layer_*` |
| 3.3 | Trajectory Curvature | κ_t (v × a form) | `canonical_kappa_*` |
| 3.4 | Trajectory Jerk | j^(l) | `canonical_jerk_*` |
| 3.5 | Directional Persistence | I_t (layer direction) | `canonical_I_layer_dir_*` |
| 3.6 | Local Tension σ_t | multi-run canonical | `canonical_sigma_t_multirun_*` |
| 3.9 | Cross-Token Coherence | c_l | `canonical_c_l_*` |
| 3.10 | Dubito Score | paradox index | `canonical_dubito_score_*` |
| 3.11 | Warning Lead Time | τ_eff | `canonical_tau_eff_lead_time` |
| 4.3 | CFKR Trigger | 1[|Δ|<ε AND I_t>0.35] | `canonical_cfkr_trigger` |
| 5.1 | Coherence C | MAD-based threshold | `canonical_coherence_C` |
| 5.2 | Fiber Curvature | σ²_head | `canonical_sigma_head_sq_*` |
| 5.3 | Decoupling Velocity | dσ²_head/dt | `canonical_decoupling_vel_*` |
| 5.4 | Attention Entropy Var | Var(H_attn) | `canonical_attn_entropy_var` |
| 5.5 | Spectral Concentration | top-k SV / total | `canonical_spectral_concentration_*` |
| 8.1 | Kuramoto R_t | canonical | `R_canonical_multirun_*`, `R_canonical_heads_*` |
| 9.1 | ANOVA Subspace | residual norm | `canonical_anova_residual` |
| 10.1 | Basin Radius | Tr(Cov(h^L)) | `canonical_basin_radius` |
| 10.2 | Norm-Growth Rate | λ_N | `canonical_norm_growth_rate` |
| 10.3 | Critical Slowing Down | lag-1 autocorr | `canonical_csd` |

### Metrics NOT in scope for this study

These glossary metrics require data we don't collect at generation time:

| Section | Why not in scope |
|---|---|
| 1.2–1.7 | Governor stack — training-time telemetry, not generation-time |
| 3.8 (SBTI) | Requires gradient info, not just hidden states |
| 5.6 (Block-4 resonance) | Requires periodic prompt forcing — different experimental setup |
| 6.1–6.6 | Instability forecasting, progress counters — training-time |
| 7.1–7.4 | Pressure tensor, CCR R_t — training-time |
| 8.2–8.4 | Tapestry, LBR, cold-start ghosts — training-time |
| 11.1–11.4 | Weight-spectrum diagnostics — requires checkpoints, not hidden states |
| 12 (SNLI audit) | Separate methodology |
| 13 (Linear probes) | Separate methodology |

For these, the glossary remains the authoritative reference; this study covers the generation-time and trajectory-geometry subset of the canonical metrics.
