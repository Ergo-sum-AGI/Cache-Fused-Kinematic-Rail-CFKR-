#!/usr/bin/env python3
"""
two_by_two_permutation.py

Question: does the MASSIF "signal" in friction_delta_pilot_v2 come from the
FEATURE FAMILY (directional/temporal features) or from the LABEL SET
(rule-based token-overlap judge vs hardened LLM judge)?

For every model it runs a 2x2:

                      hardened labels        rule-based labels
    Delta-only        cell (H, D)            cell (R, D)
    MASSIF-only       cell (H, M)            cell (R, M)

and gives each cell the SAME test: a best-feature max-statistic permutation
null. The statistic is the largest |AUROC - 0.5| over all features in the
cell's family, so the p-value already prices in the search over features.

Extras per cell
  - p_max_len : same null, but labels are shuffled WITHIN response-length
                bins, so a length-label association cannot pass as signal.
  - FDR check : per-feature permutation p-values + Benjamini-Hochberg count
                (diagnostic for "307 of 318 features survive").
  - n_eff     : effective number of independent features (participation
                ratio of the rank-correlation eigenvalues), plus the mean
                absolute pairwise correlation. If n_eff is tiny, hundreds of
                "significant" features are one feature repeated.
  - length    : AUROC of response length alone (and its permutation p).
  - optional nested-CV LASSO with its own permutation null (--lasso).
Also reported per model: agreement (kappa) between the two label sets, and
the 2x2 on the INTERSECTION of items valid under both label sets, so that
differences cannot come from a changed sample.

INPUT FILES (one pair per model, CSV; idx must match between the two files)
  features_<model>.csv : columns = idx, <feature columns...>
                         (one row per prompt; include a response-length
                          column such as n_tokens; it is used as a control
                          and is NOT tested as a feature)
  labels_<model>.csv   : columns = idx, hardened, rule
                         1 = hallucinated, 0 = correct, blank = excluded
  Export sketch for the hardened labels (adjust to your saved JSON layout):
      recs = json.load(open(path)); recs = recs.get("records", recs)
      rows = [(int(i), r.get("hallucinated")) for i, r in recs.items()]
      # keep only items where BOTH judge passes agreed on TRUE/FALSE

Delta features are recognised by --delta-regex (default: names starting with
"delta_" or "friction_delta"). Everything else (minus idx/length/labels) is
treated as the MASSIF family.

USAGE
  python two_by_two_permutation.py --demo                      # synthetic check
  python two_by_two_permutation.py --features-dir DIR --labels-dir DIR \
        --models Qwen2.5-1.5B Gemma-2B-IT Llama-3.2-1B-Instruct \
        --perms 10000 [--lasso --lasso-perms 200] --out results_2x2

STATUS: tested on synthetic data only (see --demo). Not yet run on your files.
Requires: numpy, scipy, pandas, scikit-learn.
"""
import argparse
import math
import os
import re
import sys
import tempfile
import warnings

import numpy as np
import pandas as pd
from scipy.stats import rankdata
from sklearn.metrics import cohen_kappa_score, roc_auc_score

LENGTH_CANDIDATES = ("n_tokens", "n_tok", "num_tokens", "length",
                     "response_length", "gen_len")
LABEL_SETS = ("hardened", "rule")
FAMILIES = ("delta", "massif")


# ----------------------------------------------------------------------------
# small statistics helpers
# ----------------------------------------------------------------------------
def hm_se(a, n1, n0):
    """Hanley-McNeil standard error of an AUROC."""
    a = min(max(a, 1e-6), 1 - 1e-6)
    q1, q2 = a / (2 - a), 2 * a * a / (1 + a)
    var = (a * (1 - a) + (n1 - 1) * (q1 - a * a) + (n0 - 1) * (q2 - a * a)) / (n1 * n0)
    return math.sqrt(max(var, 0.0))


def bh_reject(p, q=0.10):
    p = np.asarray(p, float)
    m = len(p)
    order = np.argsort(p)
    ok = p[order] <= q * np.arange(1, m + 1) / m
    k = (np.max(np.where(ok)[0]) + 1) if ok.any() else 0
    rej = np.zeros(m, bool)
    rej[order[:k]] = True
    return rej


def holm_adjust(p):
    p = np.asarray(p, float)
    m = len(p)
    order = np.argsort(p)
    adj = np.empty(m)
    run = 0.0
    for rank, i in enumerate(order):
        run = max(run, (m - rank) * p[i])
        adj[i] = min(1.0, run)
    return adj


def permuted_labels(y, B, rng, strata=None):
    """n x B matrix of shuffled labels; optionally shuffle within strata."""
    n = len(y)
    out = np.empty((n, B), dtype=np.float64)
    if strata is None:
        for b in range(B):
            out[:, b] = rng.permutation(y)
    else:
        groups = [np.where(strata == s)[0] for s in np.unique(strata)]
        for b in range(B):
            col = y.copy()
            for g in groups:
                col[g] = rng.permutation(y[g])
            out[:, b] = col
    return out


def length_strata(length, k):
    if length is None or k < 2:
        return None
    r = pd.Series(length).rank(method="first")
    return pd.qcut(r, q=k, labels=False).to_numpy()


# ----------------------------------------------------------------------------
# core: one cell of the 2x2
# ----------------------------------------------------------------------------
def analyse_cell(X, y, names, length, B, rng, k_strata):
    n, p = X.shape
    n1 = int(y.sum())
    n0 = n - n1
    c = n1 * (n1 + 1) / 2.0
    R = rankdata(X, axis=0)                       # average ranks for ties
    A = (R.T @ y - c) / (n1 * n0)                 # AUROC per feature
    stat = np.abs(A - 0.5)
    j = int(np.argmax(stat))
    eps = 1e-12

    Yp = permuted_labels(y, B, rng)
    Ap = (R.T @ Yp - c) / (n1 * n0)               # p x B
    nstat = np.abs(Ap - 0.5)
    p_max = (1 + np.sum(nstat.max(0) >= stat[j] - eps)) / (B + 1)
    p_feat = (1 + np.sum(nstat >= stat[:, None] - eps, axis=1)) / (B + 1)
    n_fdr = int(bh_reject(p_feat, 0.10).sum())

    p_max_len = np.nan
    strata = length_strata(length, k_strata)
    if strata is not None:
        Yp2 = permuted_labels(y, B, rng, strata)
        Ap2 = (R.T @ Yp2 - c) / (n1 * n0)
        p_max_len = (1 + np.sum(np.abs(Ap2 - 0.5).max(0) >= stat[j] - eps)) / (B + 1)

    # how many independent features are there really?
    if p > 1:
        C = np.nan_to_num(np.corrcoef(R, rowvar=False))
        lam = np.clip(np.linalg.eigvalsh(C), 0, None)
        n_eff = float(lam.sum() ** 2 / np.sum(lam ** 2))
        mean_abs_corr = float(np.abs(C[np.triu_indices(p, 1)]).mean())
    else:
        n_eff, mean_abs_corr = 1.0, float("nan")

    len_auc = len_p = np.nan
    if length is not None and np.ptp(length) > 0:
        Rl = rankdata(length)
        al = (Rl @ y - c) / (n1 * n0)
        apl = (Rl @ Yp - c) / (n1 * n0)
        len_auc = float(al)
        len_p = (1 + np.sum(np.abs(apl - 0.5) >= abs(al - 0.5) - eps)) / (B + 1)

    auc_dir = 0.5 + stat[j]                       # direction-aware (two-sided) AUROC
    se = hm_se(auc_dir, n1, n0)
    return dict(
        n=n, n_pos=n1, n_features=p, best_feature=names[j], best_auc=float(auc_dir),
        direction="high->halluc" if A[j] >= 0.5 else "low->halluc",
        auc_ci_lo=float(auc_dir - 1.96 * se), auc_ci_hi=float(auc_dir + 1.96 * se),
        p_max=p_max, p_max_len=p_max_len, n_fdr=n_fdr, frac_fdr=n_fdr / p,
        n_eff=n_eff, mean_abs_corr=mean_abs_corr,
        length_auc=len_auc, length_p=len_p,
    )


def nested_lasso_auc(X, y, seed):
    """Pooled out-of-fold AUROC; C chosen by an INNER CV on training folds."""
    from sklearn.linear_model import LogisticRegressionCV
    from sklearn.model_selection import StratifiedKFold
    from sklearn.preprocessing import StandardScaler
    nmin = int(min(y.sum(), len(y) - y.sum()))
    k_out = min(5, nmin)
    if k_out < 3:
        return float("nan")
    score = np.zeros(len(y))
    skf = StratifiedKFold(k_out, shuffle=True, random_state=seed)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        for tr, te in skf.split(X, y):
            inner = int(min(3, y[tr].sum(), len(tr) - y[tr].sum()))
            if inner < 2:
                return float("nan")
            sc = StandardScaler().fit(X[tr])
            clf = LogisticRegressionCV(
                Cs=np.logspace(-2, 1, 8), penalty="l1", solver="liblinear",
                cv=inner, scoring="roc_auc", max_iter=2000, random_state=seed)
            clf.fit(sc.transform(X[tr]), y[tr])
            score[te] = clf.decision_function(sc.transform(X[te]))
    return float(roc_auc_score(y, score))


def lasso_cell(X, y, B, rng):
    obs = nested_lasso_auc(X, y, seed=0)
    if np.isnan(obs):
        return np.nan, np.nan
    null = np.array([nested_lasso_auc(X, rng.permutation(y), seed=1 + b) for b in range(B)])
    null = null[~np.isnan(null)]
    return obs, (1 + np.sum(null >= obs - 1e-12)) / (len(null) + 1)


# ----------------------------------------------------------------------------
# loading
# ----------------------------------------------------------------------------
def _read_table(path):
    if path.endswith(".csv"):
        return pd.read_csv(path)
    if path.endswith(".json"):
        import json
        obj = json.load(open(path))
        if isinstance(obj, dict):
            return pd.DataFrame.from_dict(obj, orient="index").rename_axis("idx").reset_index()
        return pd.DataFrame(obj)
    if path.endswith(".parquet"):
        return pd.read_parquet(path)
    raise ValueError(f"unsupported file type: {path}")


def _find(dirpath, stem, model):
    for ext in (".csv", ".json", ".parquet"):
        f = os.path.join(dirpath, f"{stem}_{model}{ext}")
        if os.path.exists(f):
            return f
    raise FileNotFoundError(f"{stem}_{model}.(csv|json|parquet) not found in {dirpath}")


def to_binary(s):
    m = {"1": 1.0, "0": 0.0, "true": 1.0, "false": 0.0, "halluc": 1.0, "ok": 0.0}
    return s.map(lambda v: np.nan if pd.isna(v) else m.get(str(v).strip().lower(), np.nan)
                 if not isinstance(v, (int, float, np.integer, np.floating)) else float(v))


def load_model(features_dir, labels_dir, model):
    F = _read_table(_find(features_dir, "features", model))
    L = _read_table(_find(labels_dir, "labels", model))
    if "idx" not in F or "idx" not in L:
        raise ValueError("both files need an 'idx' column")
    for k in LABEL_SETS:
        if k not in L:
            raise ValueError(f"labels file needs a '{k}' column")
        L[k] = to_binary(L[k])
    df = F.merge(L[["idx", *LABEL_SETS]], on="idx", how="inner")
    return df, len(F), len(L)


def split_columns(df, delta_regex):
    length_col = next((c for c in df.columns if c.lower() in LENGTH_CANDIDATES), None)
    skip = {"idx", *LABEL_SETS, *( [length_col] if length_col else [] )}
    feats = [c for c in df.columns if c not in skip and pd.api.types.is_numeric_dtype(df[c])]
    rx = re.compile(delta_regex)
    delta = [c for c in feats if rx.search(c)]
    massif = [c for c in feats if c not in set(delta)]
    return length_col, {"delta": delta, "massif": massif}


def clean_matrix(df_sub, cols):
    X = df_sub[cols].astype(float)
    X = X.loc[:, X.isna().mean() <= 0.2]
    X = X.fillna(X.median())
    X = X.loc[:, X.nunique() > 1]
    return X.to_numpy(), list(X.columns)


# ----------------------------------------------------------------------------
# main analysis
# ----------------------------------------------------------------------------
def run(args):
    rng = np.random.default_rng(args.seed)
    rows, agree_rows = [], []
    for model in args.models:
        df, nf, nl = load_model(args.features_dir, args.labels_dir, model)
        print(f"\n{'=' * 78}\nMODEL {model}: {nf} feature rows, {nl} label rows, {len(df)} matched on idx")
        if len(df) < 0.8 * min(nf, nl):
            print("  WARNING: many rows failed to match on idx (check 0- vs 1-based indexing)")
        length_col, fam_cols = split_columns(df, args.delta_regex)
        print(f"  delta features: {len(fam_cols['delta'])} | massif features: {len(fam_cols['massif'])} | "
              f"length column: {length_col or 'NONE (add one!)'}")
        if not fam_cols["delta"] or not fam_cols["massif"]:
            print("  ERROR: need both families; check --delta-regex"); continue

        # label agreement
        both = df.dropna(subset=list(LABEL_SETS))
        if len(both) >= 5:
            kappa = cohen_kappa_score(both["hardened"], both["rule"]) if both["hardened"].nunique() > 1 and both["rule"].nunique() > 1 else float("nan")
            agree_rows.append(dict(
                model=model, n_hardened=int(df["hardened"].notna().sum()), n_rule=int(df["rule"].notna().sum()),
                n_both=len(both), agreement=float((both["hardened"] == both["rule"]).mean()), kappa=kappa,
                rate_hardened=float(df["hardened"].mean()), rate_rule=float(df["rule"].mean())))
            a = agree_rows[-1]
            print(f"  label sets: valid hardened={a['n_hardened']} rule={a['n_rule']} both={a['n_both']} | "
                  f"agreement={a['agreement']:.2f} kappa={a['kappa']:.2f} | halluc rate hardened={a['rate_hardened']:.2f} rule={a['rate_rule']:.2f}")

        for mode in ("full", "intersect"):
            for ls in LABEL_SETS:
                valid = df[ls].notna()
                if mode == "intersect":
                    valid &= df[[k for k in LABEL_SETS]].notna().all(axis=1)
                sub = df[valid]
                y = sub[ls].to_numpy().astype(float)
                if y.sum() < 4 or len(y) - y.sum() < 4:
                    print(f"  [{mode}/{ls}] skipped: fewer than 4 items in a class"); continue
                length = sub[length_col].to_numpy().astype(float) if length_col else None
                for fam in FAMILIES:
                    X, names = clean_matrix(sub, fam_cols[fam])
                    if X.shape[1] == 0:
                        continue
                    res = analyse_cell(X, y, names, length, args.perms, rng, args.strata)
                    if args.lasso:
                        res["lasso_auc"], res["lasso_p"] = lasso_cell(X, y, args.lasso_perms, rng)
                    res.update(model=model, sample=mode, labels=ls, family=fam)
                    rows.append(res)

    if not rows:
        print("no results"); return
    R = pd.DataFrame(rows)
    # Holm across all cells within each sample mode (the plain max-statistic p)
    R["p_max_holm"] = np.nan
    for mode in R["sample"].unique():
        idx = R.index[R["sample"] == mode]
        R.loc[idx, "p_max_holm"] = holm_adjust(R.loc[idx, "p_max"].to_numpy())
    os.makedirs(args.out, exist_ok=True)
    R.to_csv(os.path.join(args.out, "cells.csv"), index=False)
    if agree_rows:
        pd.DataFrame(agree_rows).to_csv(os.path.join(args.out, "label_agreement.csv"), index=False)

    pd.set_option("display.width", 200)
    for mode in ("intersect", "full"):
        sub = R[R["sample"] == mode]
        if sub.empty:
            continue
        print(f"\n{'#' * 78}\n2x2 RESULTS, sample = {mode}"
              f"{' (same items under both label sets)' if mode == 'intersect' else ''}\n{'#' * 78}")
        cols = ["model", "labels", "family", "n", "n_pos", "best_feature", "best_auc", "direction",
                "p_max", "p_max_len", "p_max_holm", "n_fdr", "n_features", "n_eff", "length_auc"]
        if args.lasso:
            cols += ["lasso_auc", "lasso_p"]
        print(sub[cols].to_string(index=False, float_format=lambda v: f"{v:.3f}"))
    print(READING_GUIDE)
    print(f"\nSaved: {os.path.join(args.out, 'cells.csv')}")


READING_GUIDE = """
HOW TO READ THE TABLE
  best_auc    AUROC of the best feature in its best direction (two-sided; always >= 0.5)
  p_max       best-feature permutation p (already corrected for the feature search)
  p_max_len   same, shuffling within length bins (signal beyond length)
  p_max_holm  Holm across all cells in the sample mode
  n_fdr       features with per-feature permutation FDR < 0.10; compare with n_eff.
              Hundreds of 'hits' with n_eff of a few means one effect repeated, or an
              artifact shared by all features (length, termination, template).
Patterns
  hardened/massif significant, rule/massif too   -> feature-family effect survives a label change
  only rule labels significant (either family)   -> label-set effect; treat the v2 result as an artifact
  delta significant under rule labels as well    -> the 'variance diagonal was wrong' claim is untested
  nothing significant under hardened labels      -> no replication on the better labels
Also check length_auc (signed raw AUROC of length) and p_max_len. With ~25-50 items only AUROCs above ~0.75 are detectable.
"""


# ----------------------------------------------------------------------------
# synthetic demo (pipeline check, not evidence about your data)
# ----------------------------------------------------------------------------
def make_demo(dirpath, seed=0):
    rng = np.random.default_rng(seed)
    os.makedirs(dirpath, exist_ok=True)
    specs = [("DemoNull", None), ("DemoRuleLabelsOnly", "rule"), ("DemoRealMassif", "hardened")]
    for model, planted in specs:
        n, k = 50, 12
        F = rng.normal(size=(n, k))

        def block(p):
            return F @ (rng.normal(size=(k, p)) / np.sqrt(k)) + 0.5 * rng.normal(size=(n, p))

        D, M = block(49), block(120)
        y_h = (rng.random(n) < 0.65).astype(float)
        y_r = np.where(rng.random(n) < 0.30, 1 - y_h, y_h)
        if planted == "hardened":
            M[:, :15] += 1.3 * y_h[:, None]
        if planted == "rule":
            M[:, :15] += 1.3 * y_r[:, None]
        length = rng.integers(15, 81, size=n)
        df = pd.DataFrame(np.hstack([D, M]),
                          columns=[f"delta_f{i}" for i in range(49)] + [f"massif_f{i}" for i in range(120)])
        df.insert(0, "idx", np.arange(n))
        df["n_tokens"] = length
        lab = pd.DataFrame({"idx": np.arange(n), "hardened": y_h, "rule": y_r})
        lab.loc[rng.random(n) < 0.08, "hardened"] = np.nan
        lab.loc[rng.random(n) < 0.25, "rule"] = np.nan
        df.to_csv(os.path.join(dirpath, f"features_{model}.csv"), index=False)
        lab.to_csv(os.path.join(dirpath, f"labels_{model}.csv"), index=False)
    return [m for m, _ in specs]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--features-dir"); ap.add_argument("--labels-dir")
    ap.add_argument("--models", nargs="+")
    ap.add_argument("--perms", type=int, default=10000)
    ap.add_argument("--strata", type=int, default=3, help="length bins for the stratified null")
    ap.add_argument("--delta-regex", default=r"^(delta_|friction_delta)")
    ap.add_argument("--lasso", action="store_true"); ap.add_argument("--lasso-perms", type=int, default=200)
    ap.add_argument("--out", default="results_2x2"); ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--demo", action="store_true")
    args = ap.parse_args()
    if args.demo:
        d = tempfile.mkdtemp(prefix="cfkr_demo_")
        args.models = make_demo(d)
        args.features_dir = args.labels_dir = d
        args.perms = min(args.perms, 2000)
        print(f"DEMO MODE: synthetic data in {d}; DemoNull has no signal, DemoRuleLabelsOnly has signal only "
              f"under rule labels, DemoRealMassif has signal under hardened labels.")
    if not (args.features_dir and args.labels_dir and args.models):
        ap.error("need --features-dir, --labels-dir and --models (or --demo)")
    run(args)


if __name__ == "__main__":
    main()
