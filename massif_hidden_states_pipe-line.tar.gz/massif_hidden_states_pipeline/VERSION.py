"""
VERSION
=======

Single source of truth for the MASSIF hidden-state pipeline version.
"""

VERSION = "3.3.0"
VERSION_DATE = "2026-10-26"

CHANGELOG = [
    "3.3.0 (2026-10-26): Added rejudge_with_groq.py — re-runs the Groq "
    "GPT-OSS-120b judge (matching the null pilot) on cached generations to "
    "produce hardened labels for the 2×2 confound test. prepare_2x2_data.py "
    "now auto-detects hardened_label field in meta.json",
    "3.2.0 (2026-10-26): Added two_by_two_permutation.py (user-contributed) and "
    "prepare_2x2_data.py — tests feature-family vs label-set confound with "
    "max-statistic permutation null, length-stratified null, n_eff diagnostic, "
    "and intersection analysis",
    "3.1.2 (2026-10-25): Analysis B is now defensive about analysis_a_massif "
    "version — if the loaded copy doesn't accept min_overlap, it falls back "
    "to the old signature with a clear warning instead of crashing",
    "3.1.1 (2026-10-25): Analysis B fallback now searches /content/massif_pipeline/ "
    "and /content/drive/MyDrive/massif_pipeline/ when analysis_a_massif.py "
    "isn't found in the default _this_dir",
    "3.1.0 (2026-10-25): Analysis B now self-loads analysis_a_massif via importlib; "
    "min_overlap threaded through Analysis B",
    "3.0.0 (2026-10-25): All 25 canonical glossary v5.0 metrics implemented; "
    "min_overlap parameter for rule-based judge; atomic JSON writes; "
    "self-healing meta.json recovery; notebook+CLI dual mode in all scripts",
    "2.0.0 (2026-10-22): Canonical Kuramoto R_t (Metric 8.1) per spec; "
    "per-head capture via o_proj pre-hook; multi-run support",
    "1.0.0 (2026-10-21): Initial pipeline — variance-only Friction Delta + "
    "MASSIF feature family + LASSO + permutation null",
]


def get_version():
    return f"MASSIF pipeline v{VERSION} ({VERSION_DATE})"


def print_version():
    print(get_version())
    print("Changelog:")
    for entry in CHANGELOG:
        print(f"  - {entry}")
