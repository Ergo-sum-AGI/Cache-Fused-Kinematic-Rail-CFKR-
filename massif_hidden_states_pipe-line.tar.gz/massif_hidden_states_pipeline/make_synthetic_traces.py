"""
make_synthetic_traces.py
========================

Smoke-test for the analysis pipeline. Generates synthetic hidden states
with a KNOWN signal injected (R_within_max predicts hallucination) so we
can verify that:
  (1) Analysis A correctly recovers the injected feature
  (2) Analysis B correctly assigns dynamical classes
  (3) The full pipeline runs end-to-end without errors

Also generates:
  - per-head attention outputs (for canonical H*L Kuramoto R_t)
  - multi-run hidden states (for canonical multi-run Kuramoto R_t)

Output structure mimics the real collect_hidden_states.py output:
    /tmp/massif_synthetic/<model_slug>/
        traces.npz   (with hidden_states, head_states, multirun_hidden_states)
        meta.json
"""

import os
import json
import sys
from pathlib import Path
import numpy as np

OUT = Path("/tmp/massif_synthetic")
OUT.mkdir(parents=True, exist_ok=True)

# 3 fake "models" with different layer counts
MODELS = {
    "synth_a": {"n_layers": 12, "d_model": 64, "n_heads": 8, "head_dim": 8, "n_prompts": 60, "halluc_rate": 0.5},
    "synth_b": {"n_layers": 16, "d_model": 96, "n_heads": 12, "head_dim": 8, "n_prompts": 60, "halluc_rate": 0.4},
    "synth_c": {"n_layers": 20, "d_model": 128, "n_heads": 16, "head_dim": 8, "n_prompts": 60, "halluc_rate": 0.45},
}

N_TOKENS = 30
N_MULTIRUN = 4  # greedy + 3 stochastic = 4 runs per prompt


def make_one(halluc: bool, n_layers: int, d_model: int, seed: int):
    """
    Make a synthetic hidden state trajectory.

    Hallucinated trajectories have HIGHER within-trajectory R_t (synchronization
    collapses — trajectory gets stuck in a direction).
    Correct trajectories have lower R_t (trajectory explores more).
    """
    rng = np.random.RandomState(seed)
    h = np.zeros((N_TOKENS, n_layers, d_model), dtype=np.float32)

    # base direction per layer
    base_dirs = rng.randn(n_layers, d_model).astype(np.float32)
    base_dirs /= np.linalg.norm(base_dirs, axis=-1, keepdims=True)

    if halluc:
        # hallucinated: trajectory drifts toward a fixed attractor (high R_within)
        attractor = rng.randn(d_model).astype(np.float32)
        attractor /= np.linalg.norm(attractor) + 1e-8
        for t in range(N_TOKENS):
            noise = 0.5 * rng.randn(n_layers, d_model).astype(np.float32)
            # exponential drift toward attractor
            alpha_t = 1.0 - np.exp(-t / 8.0)   # scalar
            # broadcast: alpha scalar per token, shape [n_layers, 1]
            h[t] = base_dirs * (1 - alpha_t) + attractor[None, :] * alpha_t + noise
    else:
        # correct: trajectory keeps exploring (low R_within)
        for t in range(N_TOKENS):
            noise = rng.randn(n_layers, d_model).astype(np.float32)
            h[t] = base_dirs * 0.3 + noise * (0.5 + 0.05 * t / N_TOKENS)

    return h


def make_heads(h, n_heads, head_dim, halluc: bool, seed: int):
    """Make synthetic per-head attention outputs from hidden states.
    For hallucinated: heads become MORE synchronized (low diversity = high R_t_heads).
    For correct: heads remain diverse (low R_t_heads).
    """
    rng = np.random.RandomState(seed + 9999)
    n_tok, n_layers, d_model = h.shape
    # Project hidden to per-head (just reshape, assume d_model = n_heads * head_dim)
    # If d_model != n_heads * head_dim, we'll pad/truncate
    target_d = n_heads * head_dim
    if d_model < target_d:
        pad = np.zeros((n_tok, n_layers, target_d - d_model), dtype=np.float32)
        h_proj = np.concatenate([h, pad], axis=-1)
    elif d_model > target_d:
        h_proj = h[..., :target_d]
    else:
        h_proj = h
    heads = h_proj.reshape(n_tok, n_layers, n_heads, head_dim).copy()

    if halluc:
        # add coherent shared direction to all heads (boosts R_t_heads)
        shared = rng.randn(head_dim).astype(np.float32)
        shared /= np.linalg.norm(shared) + 1e-8
        # strength grows over time (mimicking attractor lock-in)
        for t in range(n_tok):
            strength = 0.1 + 0.5 * t / N_TOKENS
            heads[t] = heads[t] + shared[None, None, :] * strength
    else:
        # add independent noise to each head (lowers R_t_heads)
        heads = heads + 0.3 * rng.randn(n_tok, n_layers, n_heads, head_dim).astype(np.float32)
    return heads


def make_multirun(h_greedy, halluc: bool, n_runs: int, seed: int):
    """Make N stochastic variants of the greedy run for canonical multi-run R_t.
    Hallucinated: runs converge to the SAME attractor (high R_t_multirun).
    Correct: runs diverge (low R_t_multirun).
    """
    rng = np.random.RandomState(seed + 7777)
    runs = []
    n_tok, n_layers, d_model = h_greedy.shape
    for r in range(n_runs):
        # perturb the greedy trajectory
        noise_scale = 0.3 if halluc else 1.0
        noise = noise_scale * rng.randn(*h_greedy.shape).astype(np.float32)
        h_r = h_greedy + noise
        if halluc:
            # bias all runs toward attractor (high coherence)
            attractor = rng.randn(d_model).astype(np.float32)
            attractor /= np.linalg.norm(attractor) + 1e-8
            for t in range(n_tok):
                alpha_t = 1.0 - np.exp(-t / 8.0)
                h_r[t] = h_r[t] * (1 - alpha_t * 0.5) + attractor[None, :] * (alpha_t * 0.5)
        runs.append(h_r)
    return runs


def main():
    for slug, cfg in MODELS.items():
        out_dir = OUT / slug
        out_dir.mkdir(parents=True, exist_ok=True)
        rng = np.random.RandomState(42)
        n_h = int(cfg["n_prompts"] * cfg["halluc_rate"])

        all_hidden = []
        all_heads = []
        all_multirun = []
        records = []
        labels = []
        for i in range(cfg["n_prompts"]):
            halluc = i < n_h
            h = make_one(halluc, cfg["n_layers"], cfg["d_model"], seed=42 + i)
            heads = make_heads(h, cfg["n_heads"], cfg["head_dim"], halluc, seed=42 + i)
            multirun = make_multirun(h, halluc, N_MULTIRUN - 1, seed=42 + i)
            all_hidden.append(h)
            all_heads.append(heads)
            all_multirun.append(multirun)
            labels.append("FALSE" if halluc else "TRUE")
            records.append({
                "id": i,
                "question": f"Synthetic question {i}?",
                "best_answer": "synthetic",
                "correct_answers": ["synthetic correct"],
                "incorrect_answers": ["synthetic incorrect"],
                "generated_text": f"synthetic response {i}",
                "token_ids": list(range(N_TOKENS)),
                "n_tokens": N_TOKENS,
                "n_layers": cfg["n_layers"],
                "d_model": cfg["d_model"],
                "n_heads": cfg["n_heads"],
                "head_dim": cfg["head_dim"],
                "multirun_n_runs": N_MULTIRUN,
                "multirun_temp": 0.7,
                "judge_label": labels[-1],
            })

        # save
        np.savez_compressed(
            out_dir / "traces.npz",
            hidden_states=np.array(all_hidden, dtype=object),
            head_states=np.array(all_heads, dtype=object),
            multirun_hidden_states=np.array(all_multirun, dtype=object),
            layer_names=np.array([f"layer_{i}" for i in range(cfg["n_layers"])]),
        )
        with open(out_dir / "meta.json", "w") as f:
            json.dump({
                "model_slug": slug,
                "hf_id": f"synthetic/{slug}",
                "n_prompts": len(records),
                "layer_names": [f"layer_{i}" for i in range(cfg["n_layers"])],
                "n_layers": cfg["n_layers"],
                "d_model": cfg["d_model"],
                "n_heads": cfg["n_heads"],
                "head_dim": cfg["head_dim"],
                "max_new_tokens": N_TOKENS,
                "multi_run_n": N_MULTIRUN,
                "multi_run_temp": 0.7,
                "captured_heads": True,
                "collected_at": "2026-01-01T00:00:00",
                "records": records,
            }, f, indent=2)
        print(f"[{slug}] {len(records)} prompts ({n_h} hallucinated) -> {out_dir}")


if __name__ == "__main__":
    main()
