#!/usr/bin/env bash
# setup_sagemaker.sh
# ==================
#
# Run this on the SageMaker notebook instance (or any EC2 box with AWS CLI).
# Downloads the massif_hidden_states data + scripts from S3, installs deps,
# and verifies the environment.
#
# Usage:
#   ./setup_sagemaker.sh s3://sagemaker-eu-central-1-119287771635/massif_migration/massif_migration.tar.gz
#
# Or if you just want to download without specifying args (uses defaults):
#   ./setup_sagemaker.sh

set -euo pipefail

# Configurable
S3_URI="${1:-s3://sagemaker-eu-central-1-119287771635/massif_migration/massif_migration.tar.gz}"
DEST_DIR="${2:-/home/ec2-user/SageMaker}"
CONDA_ENV="${3:-pytorch}"   # the env used by training

echo "============================================================"
echo "MASSIF SageMaker Setup"
echo "============================================================"
echo "S3 source:  $S3_URI"
echo "Dest dir:   $DEST_DIR"
echo "Conda env:  $CONDA_ENV"
echo

mkdir -p "$DEST_DIR"
cd "$DEST_DIR"

# 1. Download tarball
TARBALL="$DEST_DIR/massif_migration.tar.gz"
if [ -f "$TARBALL" ]; then
    echo "[1/5] tarball already exists at $TARBALL, skipping download"
else
    echo "[1/5] downloading from S3..."
    aws s3 cp "$S3_URI" "$TARBALL"
fi
echo

# 2. Extract
echo "[2/5] extracting tarball..."
tar -xzf "$TARBALL" -C "$DEST_DIR"
echo "    extracted to:"
ls -la "$DEST_DIR/scripts" 2>/dev/null | head -10
echo "---"
ls -la "$DEST_DIR/data/massif_hidden_states" 2>/dev/null | head -10
echo

# 3. Install Python deps in the conda env
echo "[3/5] installing Python deps in conda env: $CONDA_ENV"
source /home/ec2-user/anaconda3/etc/profile.d/conda.sh
conda activate "$CONDA_ENV"

# Core deps
pip install --quiet scikit-learn pandas matplotlib seaborn 2>&1 | tail -3

# Optional: groq (only needed if you want LLM judge — not required for rule-based judge)
pip install --quiet groq 2>&1 | tail -3 || echo "  (groq install failed — not critical)"

# Verify torch + transformers
python -c "import torch; print(f'  torch: {torch.__version__}, cuda: {torch.cuda.is_available()}')"
python -c "import transformers; print(f'  transformers: {transformers.__version__}')"
python -c "import sklearn; print(f'  scikit-learn: {sklearn.__version__}')"
python -c "import pandas; print(f'  pandas: {pandas.__version__}')"
echo

# 4. Verify data + scripts
echo "[4/5] verifying data and scripts..."
SCRIPTS_DIR="$DEST_DIR/scripts"
DATA_DIR="$DEST_DIR/data/massif_hidden_states"

if [ ! -f "$SCRIPTS_DIR/massif_features.py" ]; then
    echo "  ERROR: massif_features.py not found at $SCRIPTS_DIR"
    exit 1
fi
if [ ! -d "$DATA_DIR" ]; then
    echo "  ERROR: data dir not found at $DATA_DIR"
    exit 1
fi

# Check each model has traces + meta
for slug in qwen25-1.5b gemma2-2b-it llama32-1b-instruct; do
    if [ -d "$DATA_DIR/$slug" ]; then
        n_files=$(ls -1 "$DATA_DIR/$slug" | wc -l)
        size=$(du -sh "$DATA_DIR/$slug" 2>/dev/null | cut -f1)
        echo "  $slug: $n_files files, $size"
    else
        echo "  $slug: MISSING"
    fi
done
echo

# 5. Quick sanity test
echo "[5/5] running sanity test on massif_features..."
cd "$SCRIPTS_DIR"
python -c "
import sys; sys.path.insert(0, '.')
from massif_features import compute_all_features
import numpy as np
np.random.seed(0)
h = np.random.randn(30, 12, 64).astype(np.float32)
feats = compute_all_features(h)
print(f'  computed {len(feats)} features from random data — OK')
print('  smoke test PASSED')
" 2>&1 | tail -5
echo

echo "============================================================"
echo "SETUP COMPLETE"
echo "============================================================"
echo
echo "To run Analysis A (CPU, ~5-15 min):"
echo "  cd $SCRIPTS_DIR"
echo "  python analysis_a_massif.py \\"
echo "    --data-dir $DATA_DIR \\"
echo "    --min-overlap 1 --re-judge \\"
echo "    --n-permutations 200"
echo
echo "To run Analysis B (CPU, ~2 min/model):"
echo "  python analysis_b_dynamical_classes.py \\"
echo "    --data-dir $DATA_DIR"
echo
echo "To re-collect with multi-run (GPU, ~2-3h on T4):"
echo "  python collect_hidden_states.py --multi-run 5 \\"
echo "    --models qwen25-1.5b gemma2-2b-it llama32-1b-instruct"
echo
echo "Or in a notebook cell:"
echo "  import sys; sys.path.insert(0, '$SCRIPTS_DIR')"
echo "  from analysis_a_massif import main"
echo "  main(min_overlap=1, re_judge=True, n_permutations=200, data_dir='$DATA_DIR')"
