"""
VERSION
=======

Single source of truth for the MASSIF hidden-state pipeline version.
All scripts import this and print it at startup so you always know
which version you're running.

Versioning scheme: MAJOR.MINOR.PATCH
- MAJOR: changes that break backward compatibility (e.g. new feature format)
- MINOR: new features or analysis methods (e.g. canonical glossary metrics added)
- PATCH: bug fixes that don't change output semantics

Bump this version EVERY TIME you make changes that affect output or behavior.
"""

VERSION = "3.1.2"
VERSION_DATE = "2026-10-25"

# Changelog — keep brief, one line per entry, newest first
CHANGELOG = [
    "3.1.2 (2026-10-25): Analysis B is now defensive about analysis_a_massif "
    "version — if the loaded copy doesn't accept min_overlap, it falls back "
    "to the old signature with a clear warning instead of crashing",
    "3.1.1 (2026-10-25): Analysis B fallback now searches /content/massif_pipeline/ "
    "and /content/drive/MyDrive/massif_pipeline/ when analysis_a_massif.py "
    "isn't found in the default _this_dir",
    "3.1.0 (2026-10-25): Analysis B now self-loads analysis_a_massif via importlib "
    "(no more 'No module named analysis_a_massif' in notebooks); min_overlap "
    "threaded through Analysis B for consistency with Analysis A",
    "3.0.0 (2026-10-25): All 25 canonical glossary v5.0 metrics implemented; "
    "min_overlap parameter for rule-based judge; atomic JSON writes; "
    "self-healing meta.json recovery; notebook+CLI dual mode in all scripts",
    "2.0.0 (2026-10-22): Canonical Kuramoto R_t (Metric 8.1) per spec; "
    "per-head capture via o_proj pre-hook; multi-run support",
    "1.0.0 (2026-10-21): Initial pipeline — variance-only Friction Delta + "
    "MASSIF feature family + LASSO + permutation null",
]


def get_version() -> str:
    return f"MASSIF pipeline v{VERSION} ({VERSION_DATE})"


def print_version() -> None:
    print(get_version())
    print("Changelog:")
    for entry in CHANGELOG:
        print(f"  - {entry}")


if __name__ == "__main__":
    print_version()
